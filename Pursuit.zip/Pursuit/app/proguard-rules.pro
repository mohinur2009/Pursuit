# Event data is saved to JSON using enum names, so keep those names stable in release builds.
-keepclassmembers enum uz.mohinur.pursuit.data.** { *; }
