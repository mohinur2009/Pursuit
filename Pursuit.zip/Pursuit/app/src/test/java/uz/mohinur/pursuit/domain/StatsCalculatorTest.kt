package uz.mohinur.pursuit.domain

import org.junit.Assert.assertEquals
import org.junit.Test
import uz.mohinur.pursuit.data.Event
import uz.mohinur.pursuit.data.EventType
import uz.mohinur.pursuit.data.Importance
import uz.mohinur.pursuit.data.Status
import java.time.LocalDate
import java.time.ZoneOffset

class StatsCalculatorTest {

    private val zone = ZoneOffset.UTC
    private fun ms(y: Int, m: Int, d: Int) = LocalDate.of(y, m, d).atTime(9, 0).toInstant(zone).toEpochMilli()

    private fun ev(title: String, status: Status, applied: Long?, decided: Long?) = Event(
        id = title, title = title, type = EventType.OTHER, deadline = applied ?: 0L,
        importance = Importance.MEDIUM, prepDays = 1, status = status,
        createdAt = 0L, appliedAt = applied, decidedAt = decided,
    )

    @Test
    fun `counts results and compares months`() {
        val now = ms(2026, 10, 13)
        val events = listOf(
            ev("Accepted in Oct", Status.ACCEPTED, ms(2026, 10, 5), ms(2026, 10, 10)),
            ev("Waiting", Status.APPLIED, ms(2026, 10, 1), null),
            ev("Rejected in Sep", Status.REJECTED, ms(2026, 9, 10), ms(2026, 9, 20)),
            ev("Won in Sep", Status.WON, ms(2026, 9, 5), ms(2026, 9, 25)),
        )
        val s = StatsCalculator.compute(events, now, zone)

        assertEquals(4, s.submitted)
        assertEquals(2, s.successes)
        assertEquals(1, s.waiting)
        assertEquals(2f / 3f, s.winRate!!, 0.001f)
        assertEquals(2, s.thisMonth.applied)
        assertEquals(2, s.lastMonth.applied)
        assertEquals(0, s.monthlyChangePercent)
        assertEquals(6, s.history.size)
    }
}
