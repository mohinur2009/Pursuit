package uz.mohinur.pursuit.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import uz.mohinur.pursuit.data.Event
import uz.mohinur.pursuit.data.EventType
import uz.mohinur.pursuit.data.Importance
import uz.mohinur.pursuit.data.Status

class PrioritizerTest {

    private val now = 1_790_000_000_000L

    private fun ev(
        title: String,
        dueInDays: Double,
        importance: Importance,
        prep: Int = 1,
        status: Status = Status.PLANNED,
    ) = Event(
        id = title,
        title = title,
        type = EventType.OTHER,
        deadline = now + (dueInDays * DAY_MS).toLong(),
        importance = importance,
        prepDays = prep,
        status = status,
        createdAt = now,
    )

    private fun order(vararg events: Event) =
        Prioritizer.plan(events.toList(), now).active.map { it.event.title }

    @Test
    fun `important event jumps ahead when dates are close`() {
        val quiz = ev("Quiz", 2.0, Importance.LOW)
        val pitch = ev("Pizza Pitch", 4.0, Importance.MUST)
        assertEquals(listOf("Pizza Pitch", "Quiz"), order(quiz, pitch))
    }

    @Test
    fun `dates far apart keep the earlier event first`() {
        val quiz = ev("Quiz", 2.0, Importance.LOW)
        val pitch = ev("Pizza Pitch", 7.0, Importance.MUST)
        assertEquals(listOf("Quiz", "Pizza Pitch"), order(quiz, pitch))
    }

    @Test
    fun `anything due within 24 hours goes first`() {
        val form = ev("Form", 0.5, Importance.LOW, prep = 0)
        val hackathon = ev("Hackathon", 1.5, Importance.MUST, prep = 3)
        assertEquals(listOf("Form", "Hackathon"), order(hackathon, form))
    }

    @Test
    fun `longer preparation means starting earlier`() {
        val essay = ev("Essay", 6.0, Importance.MEDIUM, prep = 5)
        val quiz = ev("Quiz", 3.0, Importance.MEDIUM, prep = 1)
        assertEquals(listOf("Essay", "Quiz"), order(quiz, essay))
    }

    @Test
    fun `flags events that cannot all fit in time`() {
        val a = ev("A", 2.0, Importance.MEDIUM, prep = 2)
        val b = ev("B", 3.0, Importance.MEDIUM, prep = 2)
        val plan = Prioritizer.plan(listOf(a, b), now).active
        assertEquals(listOf("A", "B"), plan.map { it.event.title })
        assertFalse(plan[0].atRisk)
        assertTrue(plan[1].atRisk)
    }

    @Test
    fun `passed and finished events are not in the active list`() {
        val old = ev("Old", -1.0, Importance.HIGH)
        val done = ev("Done", 3.0, Importance.HIGH, status = Status.APPLIED)
        val open = ev("Open", 3.0, Importance.HIGH)
        val plan = Prioritizer.plan(listOf(old, done, open), now)
        assertEquals(listOf("Open"), plan.active.map { it.event.title })
        assertEquals(listOf("Old"), plan.missed.map { it.title })
    }
}
