package uz.mohinur.pursuit.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import uz.mohinur.pursuit.PursuitApp
import uz.mohinur.pursuit.data.Event
import uz.mohinur.pursuit.data.Settings
import uz.mohinur.pursuit.data.Status
import uz.mohinur.pursuit.data.withStatus
import uz.mohinur.pursuit.domain.Plan
import uz.mohinur.pursuit.domain.Prioritizer
import uz.mohinur.pursuit.domain.Stats
import uz.mohinur.pursuit.domain.StatsCalculator
import uz.mohinur.pursuit.reminders.ReminderScheduler

data class UiState(
    val loaded: Boolean,
    val events: List<Event>,
    val now: Long,
    val plan: Plan,
    val stats: Stats,
) {
    companion object {
        fun empty(now: Long) = UiState(
            loaded = false,
            events = emptyList(),
            now = now,
            plan = Plan.EMPTY,
            stats = StatsCalculator.compute(emptyList(), now),
        )
    }
}

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as PursuitApp

    val settings: StateFlow<Settings> = app.settingsStore.settings

    /** Ticks every 30 s so "due in…" labels and the ranking stay fresh. */
    private val clock = flow {
        while (true) {
            emit(System.currentTimeMillis())
            delay(30_000)
        }
    }

    val ui: StateFlow<UiState> = combine(app.eventStore.events, clock) { events, now ->
        if (events == null) {
            UiState.empty(now)
        } else {
            UiState(
                loaded = true,
                events = events,
                now = now,
                plan = Prioritizer.plan(events, now),
                stats = StatsCalculator.compute(events, now),
            )
        }
    }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UiState.empty(System.currentTimeMillis()))

    init {
        viewModelScope.launch { app.eventStore.load() }
    }

    fun save(event: Event) {
        viewModelScope.launch { app.eventStore.upsert(event) }
    }

    fun setStatus(event: Event, status: Status) {
        viewModelScope.launch {
            app.eventStore.upsert(event.withStatus(status, System.currentTimeMillis()))
        }
    }

    fun delete(event: Event) {
        viewModelScope.launch { app.eventStore.delete(event.id) }
    }

    fun deleteAll() {
        viewModelScope.launch { app.eventStore.clear() }
        val reset = app.settingsStore.update { Settings() }
        ReminderScheduler.apply(app, reset)
    }

    fun updateSettings(change: (Settings) -> Settings) {
        val before = settings.value
        val after = app.settingsStore.update(change)
        val reminderChanged = before.reminderMode != after.reminderMode ||
            before.reminderHour != after.reminderHour ||
            before.reminderMinute != after.reminderMinute
        if (reminderChanged) ReminderScheduler.apply(app, after)
    }
}
