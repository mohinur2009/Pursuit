package uz.mohinur.pursuit.reminders

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import uz.mohinur.pursuit.data.ReminderMode
import uz.mohinur.pursuit.data.Settings
import java.time.Duration
import java.time.ZonedDateTime
import java.util.concurrent.TimeUnit

/**
 * Reminders use WorkManager, which is Google's recommended way to run deferrable work.
 * It survives reboots, needs no special permission, and does NOT use exact alarms
 * (Google Play restricts exact alarms to alarm-clock and calendar apps).
 * The trade-off: Android may deliver the reminder a little after the chosen time.
 */
object ReminderScheduler {

    private const val WORK_NAME = "pursuit_reminders"

    fun apply(context: Context, settings: Settings) {
        val workManager = WorkManager.getInstance(context)
        if (settings.reminderMode == ReminderMode.OFF) {
            workManager.cancelUniqueWork(WORK_NAME)
            return
        }
        // Runs once a day. In Weekly mode the worker only sends the full plan on the
        // chosen weekday, and on other days only speaks up if a deadline is < 2 days away.
        val request = PeriodicWorkRequestBuilder<ReminderWorker>(1, TimeUnit.DAYS)
            .setInitialDelay(
                delayUntil(settings.reminderHour, settings.reminderMinute),
                TimeUnit.MILLISECONDS,
            )
            .build()
        workManager.enqueueUniquePeriodicWork(
            WORK_NAME,
            ExistingPeriodicWorkPolicy.CANCEL_AND_REENQUEUE,
            request,
        )
    }

    private fun delayUntil(hour: Int, minute: Int, now: ZonedDateTime = ZonedDateTime.now()): Long {
        var next = now.withHour(hour).withMinute(minute).withSecond(0).withNano(0)
        if (!next.isAfter(now)) next = next.plusDays(1)
        return Duration.between(now, next).toMillis()
    }
}
