package uz.mohinur.pursuit.data

import android.content.Context
import android.util.AtomicFile
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException

/**
 * Keeps all events in one small JSON file inside the app's private storage.
 * Nothing is sent anywhere — the app has no internet permission.
 */
class EventStore(context: Context) {

    private val file = AtomicFile(File(context.filesDir, "events.json"))
    private val mutex = Mutex()

    /** null until the file has been read for the first time. */
    private val _events = MutableStateFlow<List<Event>?>(null)
    val events: StateFlow<List<Event>?> = _events.asStateFlow()

    suspend fun load(): List<Event> = withContext(Dispatchers.IO) {
        mutex.withLock { ensureLoaded() }
    }

    suspend fun upsert(event: Event) = mutate { list ->
        val index = list.indexOfFirst { it.id == event.id }
        if (index >= 0) list.toMutableList().also { it[index] = event } else list + event
    }

    suspend fun delete(id: String) = mutate { list -> list.filterNot { it.id == id } }

    suspend fun clear() = mutate { emptyList() }

    private suspend fun mutate(change: (List<Event>) -> List<Event>) = withContext(Dispatchers.IO) {
        mutex.withLock {
            val updated = change(ensureLoaded())
            write(updated)
            _events.value = updated
        }
    }

    private fun ensureLoaded(): List<Event> =
        _events.value ?: read().also { _events.value = it }

    private fun read(): List<Event> = try {
        val text = file.openRead().bufferedReader().use { it.readText() }
        val array = JSONObject(text).optJSONArray("events") ?: JSONArray()
        (0 until array.length()).mapNotNull { i -> array.optJSONObject(i)?.toEvent() }
    } catch (e: FileNotFoundException) {
        emptyList()
    } catch (e: Exception) {
        Log.w("EventStore", "Could not read saved events", e)
        emptyList()
    }

    private fun write(events: List<Event>) {
        val array = JSONArray()
        events.forEach { array.put(it.toJson()) }
        val root = JSONObject().put("version", 1).put("events", array)
        val out = file.startWrite()
        try {
            out.write(root.toString().toByteArray(Charsets.UTF_8))
            file.finishWrite(out)
        } catch (e: IOException) {
            file.failWrite(out)
            throw e
        }
    }
}

private fun Event.toJson(): JSONObject = JSONObject().apply {
    put("id", id)
    put("title", title)
    put("type", type.name)
    put("deadline", deadline)
    put("importance", importance.name)
    put("prepDays", prepDays)
    put("status", status.name)
    put("link", link)
    put("notes", notes)
    put("createdAt", createdAt)
    appliedAt?.let { put("appliedAt", it) }
    decidedAt?.let { put("decidedAt", it) }
}

private fun JSONObject.toEvent(): Event? = runCatching {
    val deadline = getLong("deadline")
    Event(
        id = getString("id"),
        title = getString("title"),
        type = enumOr(optString("type"), EventType.OTHER),
        deadline = deadline,
        importance = enumOr(optString("importance"), Importance.MEDIUM),
        prepDays = optInt("prepDays", 1),
        status = enumOr(optString("status"), Status.PLANNED),
        link = optString("link", ""),
        notes = optString("notes", ""),
        createdAt = optLong("createdAt", deadline),
        appliedAt = if (has("appliedAt")) getLong("appliedAt") else null,
        decidedAt = if (has("decidedAt")) getLong("decidedAt") else null,
    )
}.getOrNull()

private inline fun <reified T : Enum<T>> enumOr(name: String, default: T): T =
    runCatching { enumValueOf<T>(name) }.getOrDefault(default)
