package uz.mohinur.pursuit.domain

import uz.mohinur.pursuit.data.Event
import uz.mohinur.pursuit.data.Status
import java.time.Instant
import java.time.YearMonth
import java.time.ZoneId
import kotlin.math.roundToInt

data class MonthStat(
    val month: YearMonth,
    /** Applications sent that month. */
    val applied: Int,
    /** Acceptances + wins recorded that month. */
    val successes: Int,
    /** Rejections recorded that month. */
    val rejected: Int,
) {
    val decided: Int get() = successes + rejected
    val winRate: Float? get() = if (decided == 0) null else successes.toFloat() / decided
}

data class Stats(
    val submitted: Int,
    val accepted: Int,
    val won: Int,
    val rejected: Int,
    val waiting: Int,
    val missed: Int,
    val thisMonth: MonthStat,
    val lastMonth: MonthStat,
    /** Last 6 months, oldest first. */
    val history: List<MonthStat>,
) {
    val successes: Int get() = accepted + won
    val decided: Int get() = successes + rejected

    /** Share of answered applications that were a "yes". */
    val winRate: Float? get() = if (decided == 0) null else successes.toFloat() / decided

    /** Share of deadlines you actually applied to (vs. let pass). */
    val applyRate: Float?
        get() = (submitted + missed).let { total -> if (total == 0) null else submitted.toFloat() / total }

    /** % change in applications compared with last month; null when last month had none. */
    val monthlyChangePercent: Int?
        get() = if (lastMonth.applied == 0) null
        else ((thisMonth.applied - lastMonth.applied) * 100f / lastMonth.applied).roundToInt()
}

object StatsCalculator {

    fun compute(events: List<Event>, now: Long, zone: ZoneId = ZoneId.systemDefault()): Stats {
        fun monthOf(ms: Long): YearMonth = YearMonth.from(Instant.ofEpochMilli(ms).atZone(zone))

        val current = monthOf(now)
        val months = (5 downTo 0).map { current.minusMonths(it.toLong()) }
        val submitted = events.filter { it.status.isSubmitted }

        val history = months.map { m ->
            MonthStat(
                month = m,
                applied = submitted.count { monthOf(it.appliedAt ?: it.decidedAt ?: it.deadline) == m },
                successes = events.count {
                    it.status.isSuccess && monthOf(it.decidedAt ?: it.appliedAt ?: it.deadline) == m
                },
                rejected = events.count {
                    it.status == Status.REJECTED && monthOf(it.decidedAt ?: it.appliedAt ?: it.deadline) == m
                },
            )
        }

        return Stats(
            submitted = submitted.size,
            accepted = events.count { it.status == Status.ACCEPTED },
            won = events.count { it.status == Status.WON },
            rejected = events.count { it.status == Status.REJECTED },
            waiting = events.count { it.status == Status.APPLIED },
            missed = events.count { it.status == Status.PLANNED && it.deadline <= now },
            thisMonth = history.last(),
            lastMonth = history[history.size - 2],
            history = history,
        )
    }
}
