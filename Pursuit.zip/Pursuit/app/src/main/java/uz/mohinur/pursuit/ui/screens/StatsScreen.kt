package uz.mohinur.pursuit.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.EventBusy
import androidx.compose.material.icons.rounded.HourglassTop
import androidx.compose.material.icons.rounded.Percent
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import uz.mohinur.pursuit.data.Importance
import uz.mohinur.pursuit.domain.Stats
import uz.mohinur.pursuit.ui.Fmt
import uz.mohinur.pursuit.ui.UiState
import uz.mohinur.pursuit.ui.components.ActivityChart
import uz.mohinur.pursuit.ui.components.Donut
import uz.mohinur.pursuit.ui.components.LegendDot
import uz.mohinur.pursuit.ui.components.ScreenHeader
import uz.mohinur.pursuit.ui.components.SoftCard
import uz.mohinur.pursuit.ui.components.Sparkline
import uz.mohinur.pursuit.ui.theme.LocalPalette
import uz.mohinur.pursuit.ui.theme.color

@Composable
fun StatsScreen(state: UiState, padding: PaddingValues) {
    val s = state.stats
    LazyColumn(
        contentPadding = PaddingValues(
            start = 20.dp,
            end = 20.dp,
            top = padding.calculateTopPadding() + 12.dp,
            bottom = padding.calculateBottomPadding() + 24.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item(key = "header") { ScreenHeader("Tracker", "Your applications, wins and progress") }
        item(key = "win") { WinRateCard(s) }
        item(key = "progress") { ProgressCard(s) }
        item(key = "tiles") { Tiles(s) }
        item(key = "activity") { ActivityCard(s) }
        item(key = "compare") { CompareCard(s) }
    }
}

@Composable
private fun WinRateCard(s: Stats) {
    val p = LocalPalette.current
    SoftCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Accepted & won", style = MaterialTheme.typography.titleMedium, color = p.ink)
                Text(
                    s.successes.toString(),
                    style = MaterialTheme.typography.displaySmall,
                    color = p.primary,
                )
                Text(
                    if (s.decided == 0) "Your win rate appears once you hear back from something."
                    else "${s.successes} yes out of ${s.decided} answers",
                    style = MaterialTheme.typography.bodySmall,
                    color = p.inkSoft,
                )
            }
            Spacer(Modifier.width(12.dp))
            Donut(
                fraction = s.winRate,
                color = p.primary,
                centerText = Fmt.percent(s.winRate),
                caption = "win rate",
            )
        }
    }
}

@Composable
private fun ProgressCard(s: Stats) {
    val p = LocalPalette.current
    val now = s.thisMonth.applied
    val before = s.lastMonth.applied
    val (title, body) = when {
        now == 0 && before == 0 -> "Let's get started 🚀" to
            "Tap \"I applied\" on your events and your monthly progress will show up here."
        now > before -> "Great progress 🔥" to
            "$now applications this month — ${now - before} more than last month. Keep it up!"
        now == before -> "Steady pace 💪" to
            "$now applications this month, same as last month. One more makes it a record."
        else -> "Room to grow 🌱" to
            "$now applications so far vs $before last month. Your Plan tab shows what to do next."
    }
    val change = s.monthlyChangePercent
    val (chipText, chipColor) = when {
        change == null && now > 0 -> "New" to p.success
        change == null -> "—" to p.inkSoft
        change > 0 -> "+$change%" to p.success
        change < 0 -> "$change%" to p.danger
        else -> "0%" to p.inkSoft
    }

    SoftCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, color = p.ink)
                Spacer(Modifier.height(4.dp))
                Text(body, style = MaterialTheme.typography.bodySmall, color = p.inkSoft)
            }
            Spacer(Modifier.width(12.dp))
            Column(horizontalAlignment = Alignment.End) {
                Sparkline(
                    values = s.history.map { it.applied },
                    color = Importance.MUST.color(),
                    modifier = Modifier.size(width = 96.dp, height = 44.dp),
                )
                Spacer(Modifier.height(4.dp))
                Text(chipText, style = MaterialTheme.typography.labelLarge, color = chipColor)
                Text("vs last month", style = MaterialTheme.typography.labelSmall, color = p.inkSoft)
            }
        }
    }
}

@Composable
private fun Tiles(s: Stats) {
    val p = LocalPalette.current
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Applied", s.submitted.toString(), Icons.AutoMirrored.Rounded.Send, p.primary, Modifier.weight(1f))
            StatTile("Accepted", s.accepted.toString(), Icons.Rounded.CheckCircle, p.success, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Won", s.won.toString(), Icons.Rounded.EmojiEvents, p.gold, Modifier.weight(1f))
            StatTile("Waiting", s.waiting.toString(), Icons.Rounded.HourglassTop, p.warning, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Missed deadlines", s.missed.toString(), Icons.Rounded.EventBusy, p.danger, Modifier.weight(1f))
            StatTile("Applied on time", Fmt.percent(s.applyRate), Icons.Rounded.Percent, Importance.HIGH.color(), Modifier.weight(1f))
        }
    }
}

@Composable
private fun StatTile(label: String, value: String, icon: ImageVector, color: Color, modifier: Modifier) {
    val p = LocalPalette.current
    SoftCard(modifier = modifier, contentPadding = 16.dp) {
        Box(
            Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.height(10.dp))
        Text(value, style = MaterialTheme.typography.headlineSmall, color = p.ink)
        Text(label, style = MaterialTheme.typography.bodySmall, color = p.inkSoft, maxLines = 1)
    }
}

@Composable
private fun ActivityCard(s: Stats) {
    val p = LocalPalette.current
    SoftCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Activity", style = MaterialTheme.typography.titleMedium, color = p.ink)
                Text("Last 6 months", style = MaterialTheme.typography.bodySmall, color = p.inkSoft)
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                LegendDot("Applied", p.primary)
                LegendDot("Accepted / won", Importance.MUST.color())
            }
        }
        Spacer(Modifier.height(14.dp))
        ActivityChart(
            applied = s.history.map { it.applied },
            wins = s.history.map { it.successes },
            labels = s.history.map { Fmt.month(it.month) },
        )
    }
}

@Composable
private fun CompareCard(s: Stats) {
    val p = LocalPalette.current
    SoftCard {
        Text("This month vs last month", style = MaterialTheme.typography.titleMedium, color = p.ink)
        Spacer(Modifier.height(12.dp))
        CompareRow("", "This", "Last", header = true)
        HorizontalDivider(color = p.line, modifier = Modifier.padding(vertical = 6.dp))
        CompareRow("Applications", s.thisMonth.applied.toString(), s.lastMonth.applied.toString())
        CompareRow("Accepted / won", s.thisMonth.successes.toString(), s.lastMonth.successes.toString())
        CompareRow("Win rate", Fmt.percent(s.thisMonth.winRate), Fmt.percent(s.lastMonth.winRate))
    }
}

@Composable
private fun CompareRow(label: String, now: String, before: String, header: Boolean = false) {
    val p = LocalPalette.current
    val style = if (header) MaterialTheme.typography.labelMedium else MaterialTheme.typography.bodyMedium
    val color = if (header) p.inkSoft else p.ink
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, style = style, color = color, modifier = Modifier.weight(1f))
        Text(now, style = style, color = if (header) color else p.primary, modifier = Modifier.width(64.dp), textAlign = TextAlign.End)
        Text(before, style = style, color = if (header) color else p.inkSoft, modifier = Modifier.width(64.dp), textAlign = TextAlign.End)
    }
}
