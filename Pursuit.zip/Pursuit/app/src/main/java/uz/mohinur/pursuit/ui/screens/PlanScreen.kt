package uz.mohinur.pursuit.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.TaskAlt
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.mohinur.pursuit.data.Event
import uz.mohinur.pursuit.data.ReminderMode
import uz.mohinur.pursuit.data.Settings
import uz.mohinur.pursuit.data.Status
import uz.mohinur.pursuit.domain.PlannedEvent
import uz.mohinur.pursuit.ui.Fmt
import uz.mohinur.pursuit.ui.UiState
import uz.mohinur.pursuit.ui.components.EmptyState
import uz.mohinur.pursuit.ui.components.IconBubble
import uz.mohinur.pursuit.ui.components.Pill
import uz.mohinur.pursuit.ui.components.RankingInfoDialog
import uz.mohinur.pursuit.ui.components.SectionHeader
import uz.mohinur.pursuit.ui.components.SoftCard
import uz.mohinur.pursuit.ui.components.TimeLeftRing
import uz.mohinur.pursuit.ui.components.WeekStrip
import uz.mohinur.pursuit.ui.components.icon
import uz.mohinur.pursuit.ui.theme.LocalPalette
import uz.mohinur.pursuit.ui.theme.brush
import uz.mohinur.pursuit.ui.theme.color
import java.time.Instant
import java.time.ZoneId

@Composable
fun PlanScreen(
    state: UiState,
    settings: Settings,
    padding: PaddingValues,
    onOpen: (Event) -> Unit,
    onStatus: (Event, Status) -> Unit,
    onEnableReminders: () -> Unit,
    onDismissNudge: () -> Unit,
) {
    val now = state.now
    val plan = state.plan
    var showRanking by remember { mutableStateOf(false) }
    val zone = ZoneId.systemDefault()
    val today = Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
    val dots = remember(plan) {
        plan.active
            .groupBy { Instant.ofEpochMilli(it.event.deadline).atZone(zone).toLocalDate() }
            .mapValues { (_, list) -> list.maxOf { it.event.importance } }
    }

    LazyColumn(
        contentPadding = PaddingValues(
            start = 20.dp,
            end = 20.dp,
            top = padding.calculateTopPadding() + 12.dp,
            bottom = padding.calculateBottomPadding() + 24.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item(key = "greeting") { Greeting(settings.name, now) }
        item(key = "week") { WeekStrip(today, dots) }

        if (state.loaded) {
            val first = plan.active.firstOrNull()

            if (first == null && plan.missed.isEmpty()) {
                item(key = "empty") {
                    EmptyState(
                        icon = Icons.Rounded.Flag,
                        title = "Add your first opportunity",
                        body = "Tap + and add a hackathon, internship, pitch or quiz with its deadline. " +
                            "Pursuit will put them in the best order for you.",
                    )
                }
            }

            if (first != null) {
                item(key = "focus-header") {
                    SectionHeader("Focus now", onInfo = { showRanking = true })
                }
                item(key = "focus") {
                    FocusCard(
                        item = first,
                        now = now,
                        onOpen = { onOpen(first.event) },
                        onApplied = { onStatus(first.event, Status.APPLIED) },
                    )
                }
            }

            if (settings.reminderMode == ReminderMode.OFF &&
                !settings.reminderNudgeDismissed &&
                plan.active.isNotEmpty()
            ) {
                item(key = "nudge") { ReminderNudge(onEnableReminders, onDismissNudge) }
            }

            val rest = plan.active.drop(1)
            if (rest.isNotEmpty()) {
                item(key = "next-header") {
                    SectionHeader("Up next", trailing = "${plan.active.size} open")
                }
                itemsIndexed(rest, key = { _, it -> it.event.id }) { index, item ->
                    EventRow(rank = index + 2, item = item, now = now, onClick = { onOpen(item.event) })
                }
            }

            if (plan.missed.isNotEmpty()) {
                item(key = "missed-header") { SectionHeader("Deadline passed") }
                items(plan.missed, key = { "missed-" + it.id }) { e ->
                    MissedRow(
                        event = e,
                        onOpen = { onOpen(e) },
                        onApplied = { onStatus(e, Status.APPLIED) },
                        onSkip = { onStatus(e, Status.SKIPPED) },
                    )
                }
            }
        }
    }

    if (showRanking) RankingInfoDialog { showRanking = false }
}

@Composable
private fun Greeting(name: String, now: Long) {
    val p = LocalPalette.current
    val hour = Instant.ofEpochMilli(now).atZone(ZoneId.systemDefault()).hour
    val hello = when (hour) {
        in 5..11 -> "Good morning"
        in 12..16 -> "Good afternoon"
        in 17..21 -> "Good evening"
        else -> "Hi"
    }
    Column(Modifier.padding(top = 4.dp)) {
        Text(Fmt.longDate(now), style = MaterialTheme.typography.labelLarge, color = p.inkSoft)
        Spacer(Modifier.height(2.dp))
        Text(
            if (name.isBlank()) "$hello 👋" else "$hello, ${name.trim()} 👋",
            style = MaterialTheme.typography.headlineMedium,
            color = p.ink,
        )
    }
}

/** The big gradient card for the #1 event, coloured by its importance. */
@Composable
private fun FocusCard(item: PlannedEvent, now: Long, onOpen: () -> Unit, onApplied: () -> Unit) {
    val e = item.event
    val accent = e.importance.color()
    val shape = RoundedCornerShape(28.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .shadow(14.dp, shape, ambientColor = accent, spotColor = accent)
            .clip(shape)
            .background(e.importance.brush())
            .clickable(onClick = onOpen)
    ) {
        Canvas(Modifier.matchParentSize()) {
            drawCircle(
                Color.White.copy(alpha = 0.10f),
                radius = size.height * 0.55f,
                center = Offset(size.width * 0.95f, size.height * 0.02f),
            )
            drawCircle(
                Color.White.copy(alpha = 0.07f),
                radius = size.height * 0.35f,
                center = Offset(size.width * 0.78f, size.height * 1.02f),
            )
        }
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.22f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(e.type.icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        e.type.label,
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White.copy(alpha = 0.85f),
                    )
                    Text(
                        e.title,
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(Modifier.width(8.dp))
                Pill(e.importance.label, Color.White, onGradient = true)
            }

            Spacer(Modifier.height(16.dp))
            Row {
                InfoBlock("Deadline", Fmt.dateTime(e.deadline))
                Spacer(Modifier.width(24.dp))
                if (item.startBy <= now) InfoBlock("Start", "Now")
                else InfoBlock("Start by", Fmt.date(item.startBy))
            }

            if (item.atRisk) {
                Spacer(Modifier.height(12.dp))
                Pill(
                    "Tight on time — you may not finish",
                    Color.White,
                    icon = Icons.Rounded.WarningAmber,
                    onGradient = true,
                )
            }

            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    Fmt.dueIn(e.deadline, now),
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.92f),
                    modifier = Modifier.weight(1f),
                )
                Button(
                    onClick = onApplied,
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = accent),
                ) {
                    Icon(Icons.Rounded.TaskAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("I applied")
                }
            }
        }
    }
}

@Composable
private fun InfoBlock(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.75f))
        Text(value, style = MaterialTheme.typography.titleSmall, color = Color.White)
    }
}

@Composable
private fun EventRow(rank: Int, item: PlannedEvent, now: Long, onClick: () -> Unit) {
    val p = LocalPalette.current
    val e = item.event
    val accent = e.importance.color()
    SoftCard(onClick = onClick, contentPadding = 14.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBubble(e.type, e.importance)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("#$rank", style = MaterialTheme.typography.labelMedium, color = p.inkSoft)
                    Spacer(Modifier.width(6.dp))
                    Text(
                        e.type.label.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = accent,
                        letterSpacing = 0.8.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Text(
                    e.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = p.ink,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    "${Fmt.dateTime(e.deadline)} · ${e.importance.label}",
                    style = MaterialTheme.typography.bodySmall,
                    color = p.inkSoft,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(6.dp))
                when {
                    item.atRisk -> Pill("At risk — not enough time", p.danger, icon = Icons.Rounded.WarningAmber)
                    item.dueSoon -> Pill(Fmt.dueIn(e.deadline, now), p.warning, icon = Icons.Rounded.Schedule)
                    item.startBy <= now -> Pill("Start now", accent, icon = Icons.Rounded.PlayArrow)
                    else -> Pill("Start by ${Fmt.date(item.startBy)}", p.primary)
                }
            }
            Spacer(Modifier.width(10.dp))
            TimeLeftRing(e.deadline, now, accent)
        }
    }
}

@Composable
private fun MissedRow(event: Event, onOpen: () -> Unit, onApplied: () -> Unit, onSkip: () -> Unit) {
    val p = LocalPalette.current
    SoftCard(onClick = onOpen, contentPadding = 14.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBubble(event.type, event.importance, diameter = 40.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    event.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = p.ink,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    "Deadline was ${Fmt.dateTime(event.deadline)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = p.danger,
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onApplied, modifier = Modifier.weight(1f)) { Text("I applied") }
            TextButton(onClick = onSkip, modifier = Modifier.weight(1f)) { Text("Skip it", color = p.inkSoft) }
        }
    }
}

@Composable
private fun ReminderNudge(onEnable: () -> Unit, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    SoftCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(p.primarySoft),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.NotificationsActive, contentDescription = null, tint = p.primary)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Never miss a deadline", style = MaterialTheme.typography.titleSmall, color = p.ink)
                Text(
                    "Get your plan every week and a heads-up 2 days before a deadline.",
                    style = MaterialTheme.typography.bodySmall,
                    color = p.inkSoft,
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = onDismiss) { Text("Not now", color = p.inkSoft) }
            Spacer(Modifier.width(8.dp))
            Button(onClick = onEnable, shape = RoundedCornerShape(50)) { Text("Turn on") }
        }
    }
}
