package uz.mohinur.pursuit.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import uz.mohinur.pursuit.data.Event
import uz.mohinur.pursuit.data.ReminderMode
import uz.mohinur.pursuit.reminders.Notifications
import uz.mohinur.pursuit.ui.components.AppBackground
import uz.mohinur.pursuit.ui.screens.EditEventScreen
import uz.mohinur.pursuit.ui.screens.PlanScreen
import uz.mohinur.pursuit.ui.screens.ResultsScreen
import uz.mohinur.pursuit.ui.screens.SettingsScreen
import uz.mohinur.pursuit.ui.screens.StatsScreen
import uz.mohinur.pursuit.ui.theme.LocalPalette

private const val NEW_EVENT = "__new__"

enum class Tab(val label: String) { PLAN("Plan"), RESULTS("Results"), STATS("Tracker"), SETTINGS("Settings") }

private val Tab.icon: ImageVector
    get() = when (this) {
        Tab.PLAN -> Icons.Rounded.Home
        Tab.RESULTS -> Icons.Rounded.EmojiEvents
        Tab.STATS -> Icons.Rounded.Insights
        Tab.SETTINGS -> Icons.Rounded.Settings
    }

@Composable
fun PursuitRoot(vm: AppViewModel = viewModel()) {
    val state by vm.ui.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    var tab by rememberSaveable { mutableStateOf(Tab.PLAN) }
    var editorId by rememberSaveable { mutableStateOf<String?>(null) }

    var notificationsAllowed by remember { mutableStateOf(Notifications.canPost(context)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        notificationsAllowed = Notifications.canPost(context)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        notificationsAllowed = Notifications.canPost(context)
    }

    fun chooseReminderMode(mode: ReminderMode) {
        vm.updateSettings { it.copy(reminderMode = mode, reminderNudgeDismissed = true) }
        val needsPermission = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        if (mode != ReminderMode.OFF && needsPermission) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun deleteWithUndo(event: Event) {
        vm.delete(event)
        editorId = null
        scope.launch {
            val result = snackbar.showSnackbar(
                message = "Deleted “${event.title}”",
                actionLabel = "Undo",
                duration = SnackbarDuration.Short,
            )
            if (result == SnackbarResult.ActionPerformed) vm.save(event)
        }
    }

    fun openNotificationSettings() {
        val intent = Intent(AndroidSettings.ACTION_APP_NOTIFICATION_SETTINGS)
            .putExtra(AndroidSettings.EXTRA_APP_PACKAGE, context.packageName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
    }

    AppBackground {
        val editing = editorId
        if (editing != null) {
            val initial = if (editing == NEW_EVENT) null else state.events.firstOrNull { it.id == editing }
            if (editing != NEW_EVENT && initial == null) {
                // The event no longer exists (e.g. deleted) — close the editor once data is loaded.
                LaunchedEffect(editing, state.loaded) {
                    if (state.loaded) editorId = null
                }
            } else {
                BackHandler { editorId = null }
                key(editing) {
                    EditEventScreen(
                        initial = initial,
                        onClose = { editorId = null },
                        onSave = {
                            vm.save(it)
                            editorId = null
                        },
                        onDelete = { deleteWithUndo(it) },
                    )
                }
            }
        } else {
            Scaffold(
                containerColor = Color.Transparent,
                snackbarHost = { SnackbarHost(snackbar) },
                bottomBar = { BottomBar(current = tab, onSelect = { tab = it }) },
                floatingActionButton = {
                    if (tab == Tab.PLAN || tab == Tab.RESULTS) AddButton { editorId = NEW_EVENT }
                },
            ) { inner ->
                when (tab) {
                    Tab.PLAN -> PlanScreen(
                        state = state,
                        settings = settings,
                        padding = inner,
                        onOpen = { editorId = it.id },
                        onStatus = { e, s -> vm.setStatus(e, s) },
                        onEnableReminders = { chooseReminderMode(ReminderMode.WEEKLY) },
                        onDismissNudge = { vm.updateSettings { it.copy(reminderNudgeDismissed = true) } },
                    )
                    Tab.RESULTS -> ResultsScreen(
                        state = state,
                        padding = inner,
                        onOpen = { editorId = it.id },
                        onStatus = { e, s -> vm.setStatus(e, s) },
                    )
                    Tab.STATS -> StatsScreen(state = state, padding = inner)
                    Tab.SETTINGS -> SettingsScreen(
                        settings = settings,
                        notificationsAllowed = notificationsAllowed,
                        padding = inner,
                        onUpdate = { change -> vm.updateSettings(change) },
                        onReminderMode = { chooseReminderMode(it) },
                        onOpenNotificationSettings = { openNotificationSettings() },
                        onDeleteAll = { vm.deleteAll() },
                    )
                }
            }
        }
    }
}

/** Floating rounded bottom bar like the references, with a soft pill behind the selected tab. */
@Composable
private fun BottomBar(current: Tab, onSelect: (Tab) -> Unit) {
    val p = LocalPalette.current
    val shape = RoundedCornerShape(28.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .shadow(18.dp, shape, ambientColor = p.primary.copy(alpha = 0.2f), spotColor = p.primary.copy(alpha = 0.25f))
                .clip(shape)
                .background(p.surface)
                .padding(6.dp)
        ) {
            Tab.entries.forEach { t ->
                val selected = t == current
                Column(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(22.dp))
                        .background(if (selected) p.primarySoft else Color.Transparent)
                        .selectable(selected = selected, role = Role.Tab, onClick = { onSelect(t) })
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(t.icon, contentDescription = null, tint = if (selected) p.primary else p.inkSoft)
                    Text(
                        t.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (selected) p.primary else p.inkSoft,
                    )
                }
            }
        }
    }
}

@Composable
private fun AddButton(onClick: () -> Unit) {
    val p = LocalPalette.current
    FloatingActionButton(
        onClick = onClick,
        shape = CircleShape,
        containerColor = p.primary,
        contentColor = p.onPrimary,
        elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 8.dp),
    ) {
        Icon(Icons.Rounded.Add, contentDescription = "Add opportunity", modifier = Modifier.size(28.dp))
    }
}
