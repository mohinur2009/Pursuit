package uz.mohinur.pursuit.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.mohinur.pursuit.data.Importance
import uz.mohinur.pursuit.data.Status

/**
 * Colours: a calm periwinkle-to-lavender background (focus, ambition) with bright
 * "importance" accents — teal, blue, violet and coral-pink — inspired by the references.
 */
@Immutable
data class Palette(
    val bgTop: Color,
    val bgBottom: Color,
    val surface: Color,
    val surfaceSoft: Color,
    val ink: Color,
    val inkSoft: Color,
    val line: Color,
    val primary: Color,
    val primarySoft: Color,
    val onPrimary: Color,
    val success: Color,
    val gold: Color,
    val warning: Color,
    val danger: Color,
    val isDark: Boolean,
)

val LightPalette = Palette(
    bgTop = Color(0xFFE9EDFF),
    bgBottom = Color(0xFFF5EFFF),
    surface = Color(0xFFFFFFFF),
    surfaceSoft = Color(0xFFF2F4FF),
    ink = Color(0xFF1B1E3C),
    inkSoft = Color(0xFF767C9F),
    line = Color(0xFFE4E7F6),
    primary = Color(0xFF5B5BF6),
    primarySoft = Color(0xFFE6E7FF),
    onPrimary = Color(0xFFFFFFFF),
    success = Color(0xFF12A867),
    gold = Color(0xFFE59A0B),
    warning = Color(0xFFE5850B),
    danger = Color(0xFFEB3D5F),
    isDark = false,
)

val DarkPalette = Palette(
    bgTop = Color(0xFF101330),
    bgBottom = Color(0xFF1A1436),
    surface = Color(0xFF1D2142),
    surfaceSoft = Color(0xFF272B52),
    ink = Color(0xFFF0F1FF),
    inkSoft = Color(0xFF9EA3CC),
    line = Color(0xFF30355F),
    primary = Color(0xFF8C8EFF),
    primarySoft = Color(0xFF2E3170),
    onPrimary = Color(0xFF0F1130),
    success = Color(0xFF34D399),
    gold = Color(0xFFFBBF24),
    warning = Color(0xFFFBA94C),
    danger = Color(0xFFFF6B85),
    isDark = true,
)

val LocalPalette = staticCompositionLocalOf { LightPalette }

fun Importance.color(): Color = when (this) {
    Importance.LOW -> Color(0xFF14B8A6)
    Importance.MEDIUM -> Color(0xFF4F7BFF)
    Importance.HIGH -> Color(0xFF8B5CF6)
    Importance.MUST -> Color(0xFFFF4D7E)
}

private fun Importance.lightColor(): Color = when (this) {
    Importance.LOW -> Color(0xFF4FD8C4)
    Importance.MEDIUM -> Color(0xFF7EA2FF)
    Importance.HIGH -> Color(0xFFB18CFF)
    Importance.MUST -> Color(0xFFFF8BAA)
}

fun Importance.brush(): Brush = Brush.linearGradient(listOf(lightColor(), color()))

fun Status.color(p: Palette): Color = when (this) {
    Status.PLANNED -> p.primary
    Status.APPLIED -> p.warning
    Status.ACCEPTED -> p.success
    Status.WON -> p.gold
    Status.REJECTED -> p.danger
    Status.SKIPPED -> p.inkSoft
}

private val base = Typography()

val PursuitTypography = Typography(
    displaySmall = base.displaySmall.copy(fontWeight = FontWeight.Bold, fontSize = 34.sp, letterSpacing = (-0.5).sp),
    headlineMedium = base.headlineMedium.copy(fontWeight = FontWeight.Bold, fontSize = 27.sp, letterSpacing = (-0.4).sp),
    headlineSmall = base.headlineSmall.copy(fontWeight = FontWeight.Bold),
    titleLarge = base.titleLarge.copy(fontWeight = FontWeight.Bold),
    titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
    titleSmall = base.titleSmall.copy(fontWeight = FontWeight.SemiBold),
    labelLarge = base.labelLarge.copy(fontWeight = FontWeight.SemiBold),
    labelMedium = base.labelMedium.copy(fontWeight = FontWeight.SemiBold),
    labelSmall = base.labelSmall.copy(fontWeight = FontWeight.Medium),
)

@Composable
fun PursuitTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val p = if (dark) DarkPalette else LightPalette
    val scheme = if (dark) {
        darkColorScheme(
            primary = p.primary, onPrimary = p.onPrimary,
            primaryContainer = p.primarySoft, onPrimaryContainer = p.ink,
            secondaryContainer = p.primarySoft, onSecondaryContainer = p.ink,
            background = p.bgTop, onBackground = p.ink,
            surface = p.surface, onSurface = p.ink,
            surfaceVariant = p.surfaceSoft, onSurfaceVariant = p.inkSoft,
            surfaceContainerLowest = p.surface, surfaceContainerLow = p.surface,
            surfaceContainer = p.surface, surfaceContainerHigh = p.surface,
            surfaceContainerHighest = p.surfaceSoft,
            outline = p.inkSoft, outlineVariant = p.line, error = p.danger,
        )
    } else {
        lightColorScheme(
            primary = p.primary, onPrimary = p.onPrimary,
            primaryContainer = p.primarySoft, onPrimaryContainer = p.ink,
            secondaryContainer = p.primarySoft, onSecondaryContainer = p.ink,
            background = p.bgTop, onBackground = p.ink,
            surface = p.surface, onSurface = p.ink,
            surfaceVariant = p.surfaceSoft, onSurfaceVariant = p.inkSoft,
            surfaceContainerLowest = p.surface, surfaceContainerLow = p.surface,
            surfaceContainer = p.surface, surfaceContainerHigh = p.surface,
            surfaceContainerHighest = p.surfaceSoft,
            outline = p.inkSoft, outlineVariant = p.line, error = p.danger,
        )
    }
    CompositionLocalProvider(LocalPalette provides p) {
        MaterialTheme(
            colorScheme = scheme,
            typography = PursuitTypography,
            shapes = Shapes(
                small = RoundedCornerShape(12.dp),
                medium = RoundedCornerShape(18.dp),
                large = RoundedCornerShape(24.dp),
            ),
            content = content,
        )
    }
}
