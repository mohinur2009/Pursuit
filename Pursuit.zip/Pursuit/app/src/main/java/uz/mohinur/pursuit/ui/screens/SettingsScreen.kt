package uz.mohinur.pursuit.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import uz.mohinur.pursuit.BuildConfig
import uz.mohinur.pursuit.data.ReminderMode
import uz.mohinur.pursuit.data.Settings
import uz.mohinur.pursuit.ui.Fmt
import uz.mohinur.pursuit.ui.PRIVACY_POLICY_TEXT
import uz.mohinur.pursuit.ui.components.ClockPickerDialog
import uz.mohinur.pursuit.ui.components.RankingExplanation
import uz.mohinur.pursuit.ui.components.ScreenHeader
import uz.mohinur.pursuit.ui.components.SoftCard
import uz.mohinur.pursuit.ui.theme.LocalPalette
import java.time.DayOfWeek
import java.time.format.TextStyle
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settings: Settings,
    notificationsAllowed: Boolean,
    padding: PaddingValues,
    onUpdate: ((Settings) -> Settings) -> Unit,
    onReminderMode: (ReminderMode) -> Unit,
    onOpenNotificationSettings: () -> Unit,
    onDeleteAll: () -> Unit,
) {
    val p = LocalPalette.current
    var nameText by rememberSaveable { mutableStateOf(settings.name) }
    var showTime by remember { mutableStateOf(false) }
    var showPolicy by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(
            start = 20.dp,
            end = 20.dp,
            top = padding.calculateTopPadding() + 12.dp,
            bottom = padding.calculateBottomPadding() + 24.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item(key = "header") { ScreenHeader("Settings", "Make Pursuit yours") }

        item(key = "profile") {
            SoftCard {
                CardTitle(Icons.Rounded.Person, "Your name", "Used only for the greeting on the Plan screen.")
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = nameText,
                    onValueChange = { v ->
                        nameText = v.take(30)
                        onUpdate { it.copy(name = nameText) }
                    },
                    placeholder = { Text("e.g. Mohinur") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }

        item(key = "reminders") {
            SoftCard {
                val explanation = when (settings.reminderMode) {
                    ReminderMode.OFF -> "Turn on to get your plan and deadline alerts."
                    ReminderMode.DAILY -> "Every day: what to start and what's due soon."
                    ReminderMode.WEEKLY -> "Your plan once a week, plus a heads-up when something is due within 2 days."
                }
                CardTitle(Icons.Rounded.NotificationsActive, "Reminders", explanation)
                Spacer(Modifier.height(14.dp))
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    ReminderMode.entries.forEachIndexed { index, mode ->
                        SegmentedButton(
                            selected = settings.reminderMode == mode,
                            onClick = { onReminderMode(mode) },
                            shape = SegmentedButtonDefaults.itemShape(index, ReminderMode.entries.size),
                        ) { Text(mode.label) }
                    }
                }

                if (settings.reminderMode == ReminderMode.WEEKLY) {
                    Spacer(Modifier.height(14.dp))
                    Text("Day", style = MaterialTheme.typography.labelLarge, color = p.ink)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        DayOfWeek.entries.forEach { day ->
                            val selected = settings.weeklyDay == day
                            Box(
                                Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .clip(CircleShape)
                                    .background(if (selected) p.primary else p.surfaceSoft)
                                    .selectable(
                                        selected = selected,
                                        role = Role.RadioButton,
                                        onClick = { onUpdate { it.copy(weeklyDay = day) } },
                                    ),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(
                                    day.getDisplayName(TextStyle.NARROW, Locale.getDefault()),
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (selected) p.onPrimary else p.ink,
                                )
                            }
                        }
                    }
                }

                if (settings.reminderMode != ReminderMode.OFF) {
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "Time",
                            style = MaterialTheme.typography.labelLarge,
                            color = p.ink,
                            modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = { showTime = true }) {
                            Text(Fmt.clock(settings.reminderHour, settings.reminderMinute))
                        }
                    }
                    if (!notificationsAllowed) {
                        Spacer(Modifier.height(6.dp))
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(p.danger.copy(alpha = 0.10f))
                                .padding(12.dp)
                        ) {
                            Text(
                                "Notifications are turned off for Pursuit, so reminders can't appear.",
                                style = MaterialTheme.typography.bodySmall,
                                color = p.ink,
                            )
                            TextButton(onClick = onOpenNotificationSettings) { Text("Allow notifications") }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "To save battery, Android may deliver a reminder a little after this time.",
                        style = MaterialTheme.typography.bodySmall,
                        color = p.inkSoft,
                    )
                }
            }
        }

        item(key = "ranking") {
            SoftCard {
                CardTitle(Icons.Rounded.Insights, "How your list is ordered", null)
                Spacer(Modifier.height(12.dp))
                RankingExplanation()
            }
        }

        item(key = "privacy") {
            SoftCard {
                CardTitle(
                    Icons.Rounded.Shield,
                    "Privacy",
                    "Everything you add stays on this phone. Pursuit has no account, no ads, " +
                        "no analytics and no internet access.",
                )
                TextButton(onClick = { showPolicy = true }) { Text("Read the privacy policy") }
            }
        }

        item(key = "data") {
            SoftCard {
                CardTitle(Icons.Rounded.DeleteOutline, "Your data", "Remove every event and setting from this phone.")
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Delete all my data", color = p.danger)
                }
            }
        }

        item(key = "version") {
            Text(
                "Pursuit ${BuildConfig.VERSION_NAME}",
                style = MaterialTheme.typography.labelMedium,
                color = p.inkSoft,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
            )
        }
    }

    if (showTime) {
        ClockPickerDialog(
            hour = settings.reminderHour,
            minute = settings.reminderMinute,
            onDismiss = { showTime = false },
            onConfirm = { h, m ->
                onUpdate { it.copy(reminderHour = h, reminderMinute = m) }
                showTime = false
            },
        )
    }

    if (showPolicy) {
        AlertDialog(
            onDismissRequest = { showPolicy = false },
            confirmButton = { TextButton(onClick = { showPolicy = false }) { Text("Close") } },
            title = { Text("Privacy policy") },
            text = {
                Text(
                    PRIVACY_POLICY_TEXT,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                )
            },
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete everything?") },
            text = { Text("All events, results and settings will be removed from this phone. This can't be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    nameText = ""
                    onDeleteAll()
                }) { Text("Delete", color = p.danger) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun CardTitle(icon: ImageVector, title: String, subtitle: String?) {
    val p = LocalPalette.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(p.primarySoft),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = p.primary, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = p.ink)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = p.inkSoft)
            }
        }
    }
}
