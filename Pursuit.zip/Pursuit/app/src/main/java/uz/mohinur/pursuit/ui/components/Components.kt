package uz.mohinur.pursuit.ui.components

import android.text.format.DateFormat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Event
import androidx.compose.material.icons.rounded.Functions
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.VolunteerActivism
import androidx.compose.material.icons.rounded.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.mohinur.pursuit.data.EventType
import uz.mohinur.pursuit.data.Importance
import uz.mohinur.pursuit.domain.HOUR_MS
import uz.mohinur.pursuit.ui.theme.LocalPalette
import uz.mohinur.pursuit.ui.theme.brush
import uz.mohinur.pursuit.ui.theme.color
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

val EventType.icon: ImageVector
    get() = when (this) {
        EventType.HACKATHON -> Icons.Rounded.Code
        EventType.PITCH -> Icons.Rounded.Lightbulb
        EventType.INTERNSHIP -> Icons.Rounded.Work
        EventType.COMPETITION -> Icons.Rounded.EmojiEvents
        EventType.OLYMPIAD -> Icons.Rounded.Functions
        EventType.SCHOLARSHIP -> Icons.Rounded.School
        EventType.PROGRAM -> Icons.Rounded.AutoStories
        EventType.EXAM -> Icons.Rounded.Quiz
        EventType.VOLUNTEERING -> Icons.Rounded.VolunteerActivism
        EventType.OTHER -> Icons.Rounded.Event
    }

/** Soft periwinkle → lavender background with two faint colour blobs. */
@Composable
fun AppBackground(content: @Composable BoxScope.() -> Unit) {
    val p = LocalPalette.current
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(p.bgTop, p.bgBottom)))
    ) {
        val blob = Importance.MUST.color()
        Canvas(Modifier.matchParentSize()) {
            drawCircle(
                color = p.primary.copy(alpha = 0.07f),
                radius = size.width * 0.55f,
                center = Offset(size.width * 1.05f, size.height * 0.04f),
            )
            drawCircle(
                color = blob.copy(alpha = 0.05f),
                radius = size.width * 0.5f,
                center = Offset(-size.width * 0.15f, size.height * 0.72f),
            )
        }
        content()
    }
}

/** White rounded card with a soft coloured shadow. */
@Composable
fun SoftCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    contentPadding: Dp = 18.dp,
    content: @Composable ColumnScope.() -> Unit,
) {
    val p = LocalPalette.current
    val shape = RoundedCornerShape(24.dp)
    var m = modifier
        .fillMaxWidth()
        .shadow(
            elevation = if (p.isDark) 0.dp else 8.dp,
            shape = shape,
            ambientColor = p.primary.copy(alpha = 0.10f),
            spotColor = p.primary.copy(alpha = 0.16f),
        )
        .clip(shape)
        .background(p.surface)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(contentPadding), content = content)
}

@Composable
fun IconBubble(type: EventType, importance: Importance, diameter: Dp = 48.dp) {
    Box(
        Modifier
            .size(diameter)
            .clip(CircleShape)
            .background(importance.brush()),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            type.icon,
            contentDescription = type.label,
            tint = Color.White,
            modifier = Modifier.size(diameter * 0.5f),
        )
    }
}

@Composable
fun Pill(
    text: String,
    color: Color,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    onGradient: Boolean = false,
) {
    val fg = if (onGradient) Color.White else color
    val bg = if (onGradient) Color.White.copy(alpha = 0.22f) else color.copy(alpha = 0.13f)
    Row(
        modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(4.dp))
        }
        Text(text, style = MaterialTheme.typography.labelMedium, color = fg, maxLines = 1)
    }
}

/** Ring that fills up as the deadline gets closer, with hours/days left in the middle. */
@Composable
fun TimeLeftRing(deadline: Long, now: Long, color: Color, diameter: Dp = 54.dp) {
    val p = LocalPalette.current
    val hoursLeft = ((deadline - now) / HOUR_MS).coerceAtLeast(0)
    val inHours = hoursLeft < 48
    val number = if (inHours) hoursLeft else hoursLeft / 24
    val unit = if (inHours) "h" else "d"
    val urgency = (1f - hoursLeft / (14f * 24f)).coerceIn(0.08f, 1f)
    val description = "$number ${if (inHours) "hours" else "days"} left"

    Box(
        Modifier
            .size(diameter)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.matchParentSize()) {
            val stroke = 5.dp.toPx()
            val arcSize = Size(size.width - stroke, size.height - stroke)
            val topLeft = Offset(stroke / 2, stroke / 2)
            drawArc(
                color = p.line, startAngle = 0f, sweepAngle = 360f, useCenter = false,
                topLeft = topLeft, size = arcSize, style = Stroke(stroke),
            )
            drawArc(
                color = color, startAngle = -90f, sweepAngle = 360f * urgency, useCenter = false,
                topLeft = topLeft, size = arcSize, style = Stroke(stroke, cap = StrokeCap.Round),
            )
        }
        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold, fontSize = 15.sp, color = p.ink)) {
                    append(number.toString())
                }
                withStyle(SpanStyle(fontSize = 11.sp, color = p.inkSoft)) { append(unit) }
            }
        )
    }
}

/** Donut chart like the "84%" one in the reference. */
@Composable
fun Donut(fraction: Float?, color: Color, centerText: String, diameter: Dp = 104.dp, caption: String? = null) {
    val p = LocalPalette.current
    val animated by animateFloatAsState(
        targetValue = (fraction ?: 0f).coerceIn(0f, 1f),
        animationSpec = tween(900),
        label = "donut",
    )
    Box(Modifier.size(diameter), contentAlignment = Alignment.Center) {
        Canvas(Modifier.matchParentSize()) {
            val stroke = 13.dp.toPx()
            val arcSize = Size(size.width - stroke, size.height - stroke)
            val topLeft = Offset(stroke / 2, stroke / 2)
            drawArc(
                color = p.primarySoft, startAngle = 0f, sweepAngle = 360f, useCenter = false,
                topLeft = topLeft, size = arcSize, style = Stroke(stroke),
            )
            if (animated > 0f) {
                drawArc(
                    color = color, startAngle = -90f, sweepAngle = 360f * animated, useCenter = false,
                    topLeft = topLeft, size = arcSize, style = Stroke(stroke, cap = StrokeCap.Round),
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(centerText, style = MaterialTheme.typography.titleLarge, color = p.ink)
            if (caption != null) {
                Text(caption, style = MaterialTheme.typography.labelSmall, color = p.inkSoft)
            }
        }
    }
}

fun smoothPath(points: List<Offset>): Path = Path().apply {
    if (points.isEmpty()) return@apply
    moveTo(points[0].x, points[0].y)
    for (i in 1 until points.size) {
        val a = points[i - 1]
        val b = points[i]
        val cx = (a.x + b.x) / 2
        cubicTo(cx, a.y, cx, b.y, b.x, b.y)
    }
}

@Composable
fun Sparkline(values: List<Int>, color: Color, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    Canvas(modifier) {
        if (values.size < 2) return@Canvas
        val max = (values.maxOrNull() ?: 0).coerceAtLeast(1).toFloat()
        val pad = 6.dp.toPx()
        val stepX = (size.width - 2 * pad) / (values.size - 1)
        val points = values.mapIndexed { i, v ->
            Offset(pad + i * stepX, size.height - pad - (v / max) * (size.height - 2 * pad))
        }
        drawPath(smoothPath(points), color, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
        drawCircle(p.surface, 5.dp.toPx(), points.last())
        drawCircle(color, 5.dp.toPx(), points.last(), style = Stroke(2.5.dp.toPx()))
    }
}

/** Two smooth lines (applications and acceptances) over the last months. */
@Composable
fun ActivityChart(
    applied: List<Int>,
    wins: List<Int>,
    labels: List<String>,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    val winColor = Importance.MUST.color()
    Column(modifier) {
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(150.dp)
        ) {
            val n = applied.size
            if (n == 0) return@Canvas
            val max = maxOf(applied.maxOrNull() ?: 0, wins.maxOrNull() ?: 0).coerceAtLeast(1).toFloat()
            val slot = size.width / n
            val top = 12.dp.toPx()
            val bottom = size.height - 6.dp.toPx()
            fun point(i: Int, v: Int) = Offset(slot * (i + 0.5f), bottom - (v / max) * (bottom - top))

            for (g in 0..3) {
                val y = top + (bottom - top) * g / 3f
                drawLine(
                    color = p.line, start = Offset(0f, y), end = Offset(size.width, y),
                    strokeWidth = 1.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f)),
                )
            }
            val ap = applied.mapIndexed { i, v -> point(i, v) }
            val wp = wins.mapIndexed { i, v -> point(i, v) }

            val fill = smoothPath(ap).apply {
                lineTo(ap.last().x, bottom)
                lineTo(ap.first().x, bottom)
                close()
            }
            drawPath(
                fill,
                Brush.verticalGradient(
                    listOf(p.primary.copy(alpha = 0.28f), Color.Transparent),
                    startY = top, endY = bottom,
                ),
            )
            drawPath(smoothPath(ap), p.primary, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
            drawPath(smoothPath(wp), winColor, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
            ap.forEach { drawCircle(p.primary, 3.5.dp.toPx(), it) }
            wp.forEach { drawCircle(winColor, 3.5.dp.toPx(), it) }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth()) {
            labels.forEach {
                Text(
                    it,
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.labelSmall,
                    color = p.inkSoft,
                    textAlign = TextAlign.Center,
                )
            }
        }
    }
}

@Composable
fun LegendDot(label: String, color: Color) {
    val p = LocalPalette.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(Modifier.width(5.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = p.inkSoft)
    }
}

/** The 7-day strip at the top of the Plan screen; a dot marks days with a deadline. */
@Composable
fun WeekStrip(today: LocalDate, deadlineDots: Map<LocalDate, Importance>) {
    val p = LocalPalette.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        for (offset in 0..6) {
            val day = today.plusDays(offset.toLong())
            val isToday = offset == 0
            val dot = deadlineDots[day]
            Column(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(22.dp))
                    .background(if (isToday) p.primary else p.surface.copy(alpha = 0.85f))
                    .padding(vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    day.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()).take(3),
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isToday) p.onPrimary.copy(alpha = 0.85f) else p.inkSoft,
                )
                Text(
                    day.dayOfMonth.toString(),
                    style = MaterialTheme.typography.titleMedium,
                    color = if (isToday) p.onPrimary else p.ink,
                )
                Spacer(Modifier.height(4.dp))
                Box(
                    Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                dot == null -> Color.Transparent
                                isToday -> p.onPrimary
                                else -> dot.color()
                            }
                        )
                )
            }
        }
    }
}

@Composable
fun ScreenHeader(title: String, subtitle: String) {
    val p = LocalPalette.current
    Column(Modifier.padding(top = 4.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, color = p.ink)
        Spacer(Modifier.height(2.dp))
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = p.inkSoft)
    }
}

@Composable
fun SectionHeader(title: String, trailing: String? = null, onInfo: (() -> Unit)? = null) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge, color = p.ink)
        if (onInfo != null) {
            IconButton(onClick = onInfo, modifier = Modifier.size(36.dp)) {
                Icon(
                    Icons.Rounded.Info,
                    contentDescription = "How the list is ordered",
                    tint = p.inkSoft,
                    modifier = Modifier.size(18.dp),
                )
            }
        }
        Spacer(Modifier.weight(1f))
        if (trailing != null) {
            Text(trailing, style = MaterialTheme.typography.labelLarge, color = p.primary)
        }
    }
}

@Composable
fun EmptyState(icon: ImageVector, title: String, body: String) {
    val p = LocalPalette.current
    SoftCard(contentPadding = 24.dp) {
        Box(
            Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(p.primarySoft),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = p.primary, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.height(14.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, color = p.ink)
        Spacer(Modifier.height(4.dp))
        Text(body, style = MaterialTheme.typography.bodyMedium, color = p.inkSoft)
    }
}

/** Plain-language explanation of the ranking, shown from the ⓘ button and in Settings. */
@Composable
fun RankingExplanation() {
    val p = LocalPalette.current
    val points = listOf(
        "Anything due in the next 24 hours goes to the top.",
        "Every other event gets a \"start by\" date: the deadline minus the days you need to prepare.",
        "Importance moves an event ahead: Medium by 1 day, High by 2, Must do by 3. " +
            "So a Must-do pitch can come before a Low-importance quiz that is up to 3 days earlier — but not one that is a week earlier.",
        "If you can't prepare everything in time, events are marked \"At risk\" so you can decide what to skip.",
    )
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        points.forEachIndexed { i, text ->
            Row {
                Box(
                    Modifier
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(p.primarySoft),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("${i + 1}", style = MaterialTheme.typography.labelMedium, color = p.primary)
                }
                Spacer(Modifier.width(10.dp))
                Text(text, style = MaterialTheme.typography.bodyMedium, color = p.ink)
            }
        }
    }
}

@Composable
fun RankingInfoDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Got it") } },
        title = { Text("How your list is ordered") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) { RankingExplanation() }
        },
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClockPickerDialog(hour: Int, minute: Int, onDismiss: () -> Unit, onConfirm: (Int, Int) -> Unit) {
    val context = LocalContext.current
    val state = rememberTimePickerState(
        initialHour = hour,
        initialMinute = minute,
        is24Hour = DateFormat.is24HourFormat(context),
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { onConfirm(state.hour, state.minute) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        text = { TimePicker(state = state) },
    )
}
