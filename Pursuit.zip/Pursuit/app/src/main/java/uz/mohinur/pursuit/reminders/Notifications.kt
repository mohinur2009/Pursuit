package uz.mohinur.pursuit.reminders

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import uz.mohinur.pursuit.MainActivity
import uz.mohinur.pursuit.R
import uz.mohinur.pursuit.domain.ReminderMessage

object Notifications {

    private const val CHANNEL_ID = "reminders"

    fun createChannel(context: Context) {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Reminders",
            NotificationManager.IMPORTANCE_DEFAULT,
        ).apply { description = "Your plan and upcoming deadlines" }
        context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    /** True when the app is allowed to show notifications right now. */
    fun canPost(context: Context): Boolean {
        val permissionOk = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        return permissionOk && NotificationManagerCompat.from(context).areNotificationsEnabled()
    }

    @SuppressLint("MissingPermission") // checked by canPost()
    fun show(context: Context, id: Int, message: ReminderMessage) {
        if (!canPost(context)) return

        val intent = Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pendingIntent = PendingIntent.getActivity(
            context, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_pursuit)
            .setColor(0xFF5B5BF6.toInt())
            .setContentTitle(message.title)
            .setContentText(message.text)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)

        if (message.lines.isNotEmpty()) {
            val style = NotificationCompat.InboxStyle().setBigContentTitle(message.title)
            message.lines.take(6).forEach { style.addLine(it) }
            style.setSummaryText(message.text)
            builder.setStyle(style)
        }

        NotificationManagerCompat.from(context).notify(id, builder.build())
    }
}
