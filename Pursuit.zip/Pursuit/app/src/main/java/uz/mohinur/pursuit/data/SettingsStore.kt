package uz.mohinur.pursuit.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.DayOfWeek

enum class ReminderMode(val label: String) { OFF("Off"), DAILY("Daily"), WEEKLY("Weekly") }

data class Settings(
    val name: String = "",
    val reminderMode: ReminderMode = ReminderMode.OFF,
    val reminderHour: Int = 9,
    val reminderMinute: Int = 0,
    val weeklyDay: DayOfWeek = DayOfWeek.MONDAY,
    val reminderNudgeDismissed: Boolean = false,
)

class SettingsStore(context: Context) {

    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val _settings = MutableStateFlow(read())
    val settings: StateFlow<Settings> = _settings.asStateFlow()

    @Synchronized
    fun update(change: (Settings) -> Settings): Settings {
        val s = change(_settings.value)
        prefs.edit()
            .putString("name", s.name)
            .putString("reminderMode", s.reminderMode.name)
            .putInt("reminderHour", s.reminderHour)
            .putInt("reminderMinute", s.reminderMinute)
            .putString("weeklyDay", s.weeklyDay.name)
            .putBoolean("nudgeDismissed", s.reminderNudgeDismissed)
            .apply()
        _settings.value = s
        return s
    }

    private fun read(): Settings {
        val defaults = Settings()
        return Settings(
            name = prefs.getString("name", defaults.name) ?: defaults.name,
            reminderMode = runCatching {
                ReminderMode.valueOf(prefs.getString("reminderMode", null) ?: defaults.reminderMode.name)
            }.getOrDefault(defaults.reminderMode),
            reminderHour = prefs.getInt("reminderHour", defaults.reminderHour),
            reminderMinute = prefs.getInt("reminderMinute", defaults.reminderMinute),
            weeklyDay = runCatching {
                DayOfWeek.valueOf(prefs.getString("weeklyDay", null) ?: defaults.weeklyDay.name)
            }.getOrDefault(defaults.weeklyDay),
            reminderNudgeDismissed = prefs.getBoolean("nudgeDismissed", false),
        )
    }
}
