package uz.mohinur.pursuit.domain

import uz.mohinur.pursuit.data.Event
import uz.mohinur.pursuit.data.Status

const val HOUR_MS = 60L * 60 * 1000
const val DAY_MS = 24 * HOUR_MS

data class PlannedEvent(
    val event: Event,
    /** Latest moment to start preparing: deadline minus prep days. */
    val startBy: Long,
    /** The value the list is sorted by (start-by date pulled earlier by importance). */
    val sortKey: Long,
    /** Deadline is less than 24 hours away. */
    val dueSoon: Boolean,
    /** If the student works through the list in order, this one would not be ready in time. */
    val atRisk: Boolean,
)

data class Plan(val active: List<PlannedEvent>, val missed: List<Event>) {
    companion object {
        val EMPTY = Plan(emptyList(), emptyList())
    }
}

/**
 * Orders the to-do events so the student can apply to as many as possible.
 *
 * 1. Anything due within 24 hours goes on top, soonest first.
 * 2. Everything else is ranked by its "start by" date (deadline − prep days),
 *    pulled earlier by 0–3 days depending on importance. So a "Must do" event can
 *    jump ahead of a "Low" one whose start date is up to 3 days earlier, but not more.
 *    Starting by the start date is close to "earliest deadline first", which is the
 *    order that lets you finish the most things on time.
 * 3. Walking the list in that order, any event that can't be prepared before its
 *    deadline (because earlier ones use up the time) is marked "at risk".
 */
object Prioritizer {

    fun plan(events: List<Event>, now: Long): Plan {
        val open = events.filter { it.status == Status.PLANNED }
        val missed = open.filter { it.deadline <= now }.sortedByDescending { it.deadline }

        val ordered = open
            .filter { it.deadline > now }
            .map { e ->
                val startBy = e.deadline - e.prepDays * DAY_MS
                Scored(
                    event = e,
                    startBy = startBy,
                    sortKey = startBy - e.importance.bonusDays * DAY_MS,
                    dueSoon = e.deadline - now <= DAY_MS,
                )
            }
            .sortedWith(
                compareBy<Scored>(
                    { if (it.dueSoon) 0 else 1 },
                    { if (it.dueSoon) it.event.deadline else it.sortKey },
                    { -it.event.importance.level },
                    { it.event.deadline },
                    { it.event.title.lowercase() },
                )
            )

        // Simulate doing the events one after another to spot the ones that won't fit.
        var cursor = now
        val active = ordered.map { s ->
            val finish = cursor + s.event.prepDays * DAY_MS
            val atRisk = finish > s.event.deadline
            // If it doesn't fit, you stop working on it at its deadline.
            cursor = if (atRisk) maxOf(cursor, s.event.deadline) else finish
            PlannedEvent(s.event, s.startBy, s.sortKey, s.dueSoon, atRisk)
        }
        return Plan(active, missed)
    }

    private data class Scored(
        val event: Event,
        val startBy: Long,
        val sortKey: Long,
        val dueSoon: Boolean,
    )
}
