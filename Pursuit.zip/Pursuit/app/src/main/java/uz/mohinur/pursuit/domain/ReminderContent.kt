package uz.mohinur.pursuit.domain

import uz.mohinur.pursuit.data.Event
import uz.mohinur.pursuit.data.Status
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

data class ReminderMessage(val title: String, val text: String, val lines: List<String>)

/** Builds the text of a reminder notification. Pure Kotlin so it is easy to test. */
object ReminderContent {

    /**
     * @param digest true on the day a full plan should be sent (every day in Daily mode,
     *               the chosen weekday in Weekly mode). Otherwise only urgent deadlines are sent.
     */
    fun build(
        events: List<Event>,
        now: Long,
        digest: Boolean,
        daily: Boolean,
        zone: ZoneId = ZoneId.systemDefault(),
    ): ReminderMessage? {
        val plan = Prioritizer.plan(events, now)
        val fmt = DateTimeFormatter.ofPattern("EEE d MMM", Locale.getDefault())
        fun day(ms: Long) = Instant.ofEpochMilli(ms).atZone(zone).format(fmt)

        val urgent = plan.active.filter { it.event.deadline - now <= 2 * DAY_MS }

        if (!digest) {
            if (urgent.isEmpty()) return null
            if (urgent.size == 1) {
                val e = urgent.first().event
                return ReminderMessage(
                    title = "Deadline soon: ${e.title}",
                    text = "Due ${day(e.deadline)}. Did you apply yet?",
                    lines = emptyList(),
                )
            }
            return ReminderMessage(
                title = "${urgent.size} deadlines in the next 2 days",
                text = urgent.joinToString { it.event.title },
                lines = urgent.map { "• ${it.event.title} — due ${day(it.event.deadline)}" },
            )
        }

        val followUps = events.filter {
            it.status == Status.APPLIED && (it.appliedAt ?: now) <= now - 14 * DAY_MS
        }
        if (plan.active.isEmpty() && followUps.isEmpty()) return null

        val lines = mutableListOf<String>()
        plan.active.take(3).forEachIndexed { i, p ->
            val action = if (p.startBy <= now) "start now" else "start by ${day(p.startBy)}"
            lines += "${i + 1}. ${p.event.title} — $action"
        }
        val atRisk = plan.active.count { it.atRisk }
        if (atRisk > 0) lines += "⚠ $atRisk at risk — consider skipping something"
        followUps.take(2).forEach { lines += "Any news from ${it.title}? Record the result" }

        val window = if (daily) DAY_MS else 7 * DAY_MS
        val dueInWindow = plan.active.count { it.event.deadline - now <= window }
        val windowText = if (daily) "24 hours" else "7 days"
        return ReminderMessage(
            title = if (daily) "Your plan for today" else "Your plan for this week",
            text = "${plan.active.size} open · $dueInWindow due in the next $windowText",
            lines = lines,
        )
    }
}
