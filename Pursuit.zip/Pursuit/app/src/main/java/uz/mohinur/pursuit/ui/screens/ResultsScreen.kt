package uz.mohinur.pursuit.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.HourglassTop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import uz.mohinur.pursuit.data.Event
import uz.mohinur.pursuit.data.Status
import uz.mohinur.pursuit.ui.Fmt
import uz.mohinur.pursuit.ui.UiState
import uz.mohinur.pursuit.ui.components.EmptyState
import uz.mohinur.pursuit.ui.components.IconBubble
import uz.mohinur.pursuit.ui.components.Pill
import uz.mohinur.pursuit.ui.components.ScreenHeader
import uz.mohinur.pursuit.ui.components.SectionHeader
import uz.mohinur.pursuit.ui.components.SoftCard
import uz.mohinur.pursuit.ui.theme.LocalPalette
import uz.mohinur.pursuit.ui.theme.color

@Composable
fun ResultsScreen(
    state: UiState,
    padding: PaddingValues,
    onOpen: (Event) -> Unit,
    onStatus: (Event, Status) -> Unit,
) {
    val p = LocalPalette.current
    val waiting = state.events.filter { it.status == Status.APPLIED }.sortedBy { it.appliedAt ?: it.deadline }
    val decided = state.events.filter { it.status.isDecided }.sortedByDescending { it.decidedAt ?: it.deadline }
    val skipped = state.events.filter { it.status == Status.SKIPPED }.sortedByDescending { it.deadline }

    LazyColumn(
        contentPadding = PaddingValues(
            start = 20.dp,
            end = 20.dp,
            top = padding.calculateTopPadding() + 12.dp,
            bottom = padding.calculateBottomPadding() + 24.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item(key = "header") { ScreenHeader("Results", "Record what happened after you applied") }
        item(key = "summary") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MiniStat("Waiting", waiting.size, p.warning, Modifier.weight(1f))
                MiniStat("Yes!", state.stats.successes, p.success, Modifier.weight(1f))
                MiniStat("No", state.stats.rejected, p.danger, Modifier.weight(1f))
            }
        }

        if (state.loaded && waiting.isEmpty() && decided.isEmpty() && skipped.isEmpty()) {
            item(key = "empty") {
                EmptyState(
                    icon = Icons.Rounded.EmojiEvents,
                    title = "No applications yet",
                    body = "When you tap \"I applied\" on an event, it moves here so you can record " +
                        "whether you were accepted, won, or not.",
                )
            }
        }

        if (waiting.isNotEmpty()) {
            item(key = "waiting-header") { SectionHeader("Waiting for an answer") }
            items(waiting, key = { "w-" + it.id }) { e ->
                WaitingCard(e, onOpen = { onOpen(e) }, onStatus = { s -> onStatus(e, s) })
            }
        }
        if (decided.isNotEmpty()) {
            item(key = "decided-header") { SectionHeader("Decided") }
            items(decided, key = { "d-" + it.id }) { e -> ResultRow(e, onOpen = { onOpen(e) }) }
        }
        if (skipped.isNotEmpty()) {
            item(key = "skipped-header") { SectionHeader("Skipped") }
            items(skipped, key = { "s-" + it.id }) { e -> ResultRow(e, onOpen = { onOpen(e) }) }
        }
    }
}

@Composable
private fun MiniStat(label: String, value: Int, color: Color, modifier: Modifier) {
    val p = LocalPalette.current
    SoftCard(modifier = modifier, contentPadding = 14.dp) {
        Text(value.toString(), style = MaterialTheme.typography.headlineSmall, color = color)
        Text(label, style = MaterialTheme.typography.labelMedium, color = p.inkSoft)
    }
}

@Composable
private fun WaitingCard(event: Event, onOpen: () -> Unit, onStatus: (Status) -> Unit) {
    val p = LocalPalette.current
    SoftCard(onClick = onOpen, contentPadding = 16.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBubble(event.type, event.importance, diameter = 42.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    event.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = p.ink,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    "Applied ${Fmt.date(event.appliedAt ?: event.deadline)} · ${event.type.label}",
                    style = MaterialTheme.typography.bodySmall,
                    color = p.inkSoft,
                )
            }
            Icon(Icons.Rounded.HourglassTop, contentDescription = "Waiting", tint = p.warning)
        }
        Spacer(Modifier.height(12.dp))
        Text("What happened?", style = MaterialTheme.typography.labelMedium, color = p.inkSoft)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutcomeButton("Accepted", Icons.Rounded.CheckCircle, p.success) { onStatus(Status.ACCEPTED) }
            OutcomeButton("Won", Icons.Rounded.EmojiEvents, p.gold) { onStatus(Status.WON) }
            OutcomeButton("Rejected", Icons.Rounded.Close, p.danger) { onStatus(Status.REJECTED) }
        }
    }
}

@Composable
private fun RowScope.OutcomeButton(label: String, icon: ImageVector, color: Color, onClick: () -> Unit) {
    Row(
        Modifier
            .weight(1f)
            .clip(RoundedCornerShape(14.dp))
            .background(color.copy(alpha = 0.12f))
            .clickable(role = Role.Button, onClick = onClick)
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(4.dp))
        Text(label, style = MaterialTheme.typography.labelLarge, color = color, maxLines = 1)
    }
}

@Composable
private fun ResultRow(event: Event, onOpen: () -> Unit) {
    val p = LocalPalette.current
    SoftCard(onClick = onOpen, contentPadding = 14.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBubble(event.type, event.importance, diameter = 42.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    event.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = p.ink,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    Fmt.date(event.decidedAt ?: event.deadline),
                    style = MaterialTheme.typography.bodySmall,
                    color = p.inkSoft,
                )
            }
            Spacer(Modifier.width(8.dp))
            Pill(event.status.label, event.status.color(p))
        }
    }
}
