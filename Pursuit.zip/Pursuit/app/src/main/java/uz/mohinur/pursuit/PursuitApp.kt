package uz.mohinur.pursuit

import android.app.Application
import uz.mohinur.pursuit.data.EventStore
import uz.mohinur.pursuit.data.SettingsStore
import uz.mohinur.pursuit.reminders.Notifications

class PursuitApp : Application() {

    lateinit var eventStore: EventStore
        private set
    lateinit var settingsStore: SettingsStore
        private set

    override fun onCreate() {
        super.onCreate()
        eventStore = EventStore(this)
        settingsStore = SettingsStore(this)
        Notifications.createChannel(this)
    }
}
