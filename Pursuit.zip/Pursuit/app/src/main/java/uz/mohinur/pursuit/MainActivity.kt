package uz.mohinur.pursuit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import uz.mohinur.pursuit.ui.PursuitRoot
import uz.mohinur.pursuit.ui.theme.PursuitTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Android 16 always draws apps edge-to-edge; the UI handles the system bar insets.
        enableEdgeToEdge()
        setContent {
            PursuitTheme {
                PursuitRoot()
            }
        }
    }
}
