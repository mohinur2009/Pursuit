package uz.mohinur.pursuit.data

import java.util.UUID

/** What kind of opportunity it is. defaultPrepDays is a starting guess the user can change. */
enum class EventType(val label: String, val defaultPrepDays: Int) {
    HACKATHON("Hackathon", 3),
    PITCH("Pitch / Startup", 2),
    INTERNSHIP("Internship", 3),
    COMPETITION("Competition", 3),
    OLYMPIAD("Olympiad", 5),
    SCHOLARSHIP("Scholarship", 4),
    PROGRAM("Program / Camp", 3),
    EXAM("Exam / Quiz", 2),
    VOLUNTEERING("Volunteering", 1),
    OTHER("Other", 1),
}

/**
 * bonusDays = how many days earlier an event is treated when the list is ranked.
 * Each step up in importance lets an event jump ahead by about one day.
 */
enum class Importance(val label: String, val level: Int, val bonusDays: Int) {
    LOW("Low", 1, 0),
    MEDIUM("Medium", 2, 1),
    HIGH("High", 3, 2),
    MUST("Must do", 4, 3),
}

enum class Status(val label: String) {
    PLANNED("To do"),
    APPLIED("Applied"),
    ACCEPTED("Accepted"),
    WON("Won"),
    REJECTED("Rejected"),
    SKIPPED("Skipped");

    /** Got an answer back. */
    val isDecided: Boolean get() = this == ACCEPTED || this == WON || this == REJECTED

    /** The student sent an application (with or without an answer yet). */
    val isSubmitted: Boolean get() = this == APPLIED || isDecided

    /** A "yes": accepted, or won a competition. */
    val isSuccess: Boolean get() = this == ACCEPTED || this == WON
}

data class Event(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val type: EventType,
    /** Deadline as epoch milliseconds. */
    val deadline: Long,
    val importance: Importance,
    /** Days of work needed before the deadline (0 = just submit). */
    val prepDays: Int,
    val status: Status = Status.PLANNED,
    val link: String = "",
    val notes: String = "",
    val createdAt: Long,
    /** When it was marked as applied — used for the monthly tracker. */
    val appliedAt: Long? = null,
    /** When the result (accepted / won / rejected) was recorded. */
    val decidedAt: Long? = null,
)

/** Changes the status and keeps the timestamps the tracker relies on consistent. */
fun Event.withStatus(newStatus: Status, now: Long): Event {
    if (newStatus == status) return this
    val applied = if (newStatus.isSubmitted) appliedAt ?: now else null
    val decided = when {
        !newStatus.isDecided -> null
        status.isDecided && decidedAt != null -> decidedAt
        else -> now
    }
    return copy(status = newStatus, appliedAt = applied, decidedAt = decided)
}
