package uz.mohinur.pursuit.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import uz.mohinur.pursuit.data.Event
import uz.mohinur.pursuit.data.EventType
import uz.mohinur.pursuit.data.Importance
import uz.mohinur.pursuit.data.Status
import uz.mohinur.pursuit.data.withStatus
import uz.mohinur.pursuit.ui.Fmt
import uz.mohinur.pursuit.ui.components.ClockPickerDialog
import uz.mohinur.pursuit.ui.components.SoftCard
import uz.mohinur.pursuit.ui.components.icon
import uz.mohinur.pursuit.ui.theme.LocalPalette
import uz.mohinur.pursuit.ui.theme.brush
import uz.mohinur.pursuit.ui.theme.color
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun EditEventScreen(
    initial: Event?,
    onClose: () -> Unit,
    onSave: (Event) -> Unit,
    onDelete: (Event) -> Unit,
) {
    val p = LocalPalette.current
    val zone = ZoneId.systemDefault()
    val isNew = initial == null

    var title by rememberSaveable { mutableStateOf(initial?.title ?: "") }
    var type by rememberSaveable { mutableStateOf(initial?.type ?: EventType.HACKATHON) }
    var importance by rememberSaveable { mutableStateOf(initial?.importance ?: Importance.MEDIUM) }
    var prepDays by rememberSaveable { mutableIntStateOf(initial?.prepDays ?: EventType.HACKATHON.defaultPrepDays) }
    var prepTouched by rememberSaveable { mutableStateOf(!isNew) }
    var deadline by rememberSaveable { mutableLongStateOf(initial?.deadline ?: defaultDeadline(zone)) }
    var status by rememberSaveable { mutableStateOf(initial?.status ?: Status.PLANNED) }
    var link by rememberSaveable { mutableStateOf(initial?.link ?: "") }
    var notes by rememberSaveable { mutableStateOf(initial?.notes ?: "") }
    var attempted by rememberSaveable { mutableStateOf(false) }

    var showDate by remember { mutableStateOf(false) }
    var showTime by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    val titleError = attempted && title.isBlank()
    val deadlineError = attempted && isNew && deadline <= System.currentTimeMillis()

    fun save() {
        attempted = true
        val now = System.currentTimeMillis()
        if (title.isBlank() || (isNew && deadline <= now)) return
        val base = initial ?: Event(
            title = title.trim(), type = type, deadline = deadline,
            importance = importance, prepDays = prepDays, createdAt = now,
        )
        val updated = base.copy(
            title = title.trim(),
            type = type,
            deadline = deadline,
            importance = importance,
            prepDays = prepDays,
            link = link.trim(),
            notes = notes.trim(),
        )
        onSave(updated.withStatus(status, now))
    }

    Column(
        Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, contentDescription = "Close", tint = p.ink) }
            Text(
                if (isNew) "New opportunity" else "Edit",
                style = MaterialTheme.typography.titleLarge,
                color = p.ink,
                modifier = Modifier.weight(1f),
            )
            if (initial != null) {
                IconButton(onClick = { confirmDelete = true }) {
                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete", tint = p.danger)
                }
            }
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // Name + type
            SoftCard {
                FieldLabel("What is it?")
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it.take(80) },
                    placeholder = { Text("e.g. WIUT Hackathon") },
                    singleLine = true,
                    isError = titleError,
                    supportingText = if (titleError) {
                        { Text("Give it a name") }
                    } else null,
                    shape = RoundedCornerShape(16.dp),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Sentences,
                        imeAction = ImeAction.Done,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(14.dp))
                FieldLabel("Type")
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    EventType.entries.forEach { t ->
                        FilterChip(
                            selected = type == t,
                            onClick = {
                                type = t
                                if (!prepTouched) prepDays = t.defaultPrepDays
                            },
                            label = { Text(t.label) },
                            leadingIcon = { Icon(t.icon, contentDescription = null, modifier = Modifier.size(18.dp)) },
                            shape = RoundedCornerShape(50),
                        )
                    }
                }
            }

            // Deadline
            SoftCard {
                FieldLabel("Deadline")
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PickerField(Icons.Rounded.CalendarMonth, Fmt.fullDate(deadline), Modifier.weight(1.4f)) {
                        showDate = true
                    }
                    PickerField(Icons.Rounded.Schedule, Fmt.time(deadline), Modifier.weight(1f)) {
                        showTime = true
                    }
                }
                if (deadlineError) {
                    Spacer(Modifier.height(6.dp))
                    Text("Pick a deadline in the future", style = MaterialTheme.typography.bodySmall, color = p.danger)
                }
            }

            // Importance
            SoftCard {
                FieldLabel("How important is it?")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Importance.entries.forEach { imp ->
                        ImportanceOption(imp, selected = imp == importance, modifier = Modifier.weight(1f)) {
                            importance = imp
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(importanceHint(importance), style = MaterialTheme.typography.bodySmall, color = p.inkSoft)
            }

            // Preparation time
            SoftCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Time to prepare",
                        style = MaterialTheme.typography.titleSmall,
                        color = p.ink,
                        modifier = Modifier.weight(1f),
                    )
                    Text(Fmt.prepDays(prepDays), style = MaterialTheme.typography.labelLarge, color = p.primary)
                }
                Slider(
                    value = prepDays.toFloat(),
                    onValueChange = {
                        prepDays = it.roundToInt()
                        prepTouched = true
                    },
                    valueRange = 0f..14f,
                    steps = 13,
                )
                Text(
                    "Days of work you need before the deadline (writing, building, practising). " +
                        "Pursuit uses it to tell you when to start.",
                    style = MaterialTheme.typography.bodySmall,
                    color = p.inkSoft,
                )
            }

            // Status (only when editing)
            if (!isNew) {
                SoftCard {
                    FieldLabel("Status")
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Status.entries.forEach { s ->
                            FilterChip(
                                selected = status == s,
                                onClick = { status = s },
                                label = { Text(s.label) },
                                shape = RoundedCornerShape(50),
                            )
                        }
                    }
                }
            }

            // Link + notes
            SoftCard {
                val uriHandler = LocalUriHandler.current
                val cleanLink = link.trim()
                FieldLabel("Link (optional)")
                OutlinedTextField(
                    value = link,
                    onValueChange = { link = it.take(300) },
                    placeholder = { Text("Application page") },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Rounded.Link, contentDescription = null) },
                    trailingIcon = if (cleanLink.isNotEmpty()) {
                        {
                            IconButton(onClick = {
                                val url = if (cleanLink.startsWith("http://") || cleanLink.startsWith("https://")) {
                                    cleanLink
                                } else {
                                    "https://$cleanLink"
                                }
                                runCatching { uriHandler.openUri(url) }
                            }) {
                                Icon(Icons.AutoMirrored.Rounded.OpenInNew, contentDescription = "Open link")
                            }
                        }
                    } else null,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Done),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(14.dp))
                FieldLabel("Notes (optional)")
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it.take(1000) },
                    placeholder = { Text("Team, requirements, documents to prepare…") },
                    minLines = 3,
                    shape = RoundedCornerShape(16.dp),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }

        Button(
            onClick = { save() },
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .height(56.dp),
        ) {
            Text(if (isNew) "Add to my list" else "Save changes", style = MaterialTheme.typography.titleSmall)
        }
    }

    if (showDate) {
        val currentDate = Instant.ofEpochMilli(deadline).atZone(zone).toLocalDate()
        val pickerState = rememberDatePickerState(
            initialSelectedDateMillis = currentDate.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli(),
        )
        DatePickerDialog(
            onDismissRequest = { showDate = false },
            confirmButton = {
                TextButton(onClick = {
                    pickerState.selectedDateMillis?.let { selected ->
                        val newDate = Instant.ofEpochMilli(selected).atZone(ZoneOffset.UTC).toLocalDate()
                        val time = Instant.ofEpochMilli(deadline).atZone(zone).toLocalTime()
                        deadline = newDate.atTime(time).atZone(zone).toInstant().toEpochMilli()
                    }
                    showDate = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showDate = false }) { Text("Cancel") } },
        ) {
            DatePicker(state = pickerState)
        }
    }

    if (showTime) {
        val current = Instant.ofEpochMilli(deadline).atZone(zone)
        ClockPickerDialog(
            hour = current.hour,
            minute = current.minute,
            onDismiss = { showTime = false },
            onConfirm = { h, m ->
                deadline = current.toLocalDate().atTime(h, m).atZone(zone).toInstant().toEpochMilli()
                showTime = false
            },
        )
    }

    if (confirmDelete && initial != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete “${initial.title}”?") },
            text = { Text("It will be removed from your list and from your tracker.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    onDelete(initial)
                }) { Text("Delete", color = p.danger) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }
}

private fun defaultDeadline(zone: ZoneId): Long =
    LocalDate.now(zone).plusDays(7).atTime(23, 59).atZone(zone).toInstant().toEpochMilli()

private fun importanceHint(importance: Importance): String = when (importance) {
    Importance.LOW -> "Nice to have. Ranked only by its dates."
    Importance.MEDIUM -> "Can move ahead of a Low event that starts up to 1 day earlier."
    Importance.HIGH -> "Can move ahead of a Low event that starts up to 2 days earlier."
    Importance.MUST -> "Top priority. Can move ahead of a Low event that starts up to 3 days earlier."
}

@Composable
private fun FieldLabel(text: String) {
    val p = LocalPalette.current
    Text(
        text,
        style = MaterialTheme.typography.titleSmall,
        color = p.ink,
        modifier = Modifier.padding(bottom = 8.dp),
    )
}

@Composable
private fun PickerField(icon: ImageVector, value: String, modifier: Modifier, onClick: () -> Unit) {
    val p = LocalPalette.current
    Row(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(p.surfaceSoft)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = p.primary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            color = p.ink,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun ImportanceOption(imp: Importance, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    val fg = if (selected) Color.White else imp.color()
    Column(
        modifier
            .clip(shape)
            .then(
                if (selected) Modifier.background(imp.brush())
                else Modifier.background(imp.color().copy(alpha = 0.10f))
            )
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            repeat(imp.level) {
                Box(
                    Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(fg)
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(imp.label, style = MaterialTheme.typography.labelMedium, color = fg, maxLines = 1)
    }
}
