package uz.mohinur.pursuit.ui

import uz.mohinur.pursuit.domain.DAY_MS
import uz.mohinur.pursuit.domain.HOUR_MS
import java.time.Instant
import java.time.LocalTime
import java.time.YearMonth
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.roundToInt

/** Small helpers that turn timestamps and numbers into friendly text. */
object Fmt {
    private fun zdt(ms: Long): ZonedDateTime = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault())
    private fun pattern(p: String) = DateTimeFormatter.ofPattern(p, Locale.getDefault())
    private fun shortTime() = DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT).withLocale(Locale.getDefault())

    fun date(ms: Long): String = zdt(ms).format(pattern("EEE, d MMM"))
    fun fullDate(ms: Long): String = zdt(ms).format(pattern("EEE, d MMM yyyy"))
    fun longDate(ms: Long): String = zdt(ms).format(pattern("EEEE, d MMMM"))
    fun time(ms: Long): String = zdt(ms).format(shortTime())
    fun dateTime(ms: Long): String = "${date(ms)} · ${time(ms)}"
    fun clock(hour: Int, minute: Int): String = LocalTime.of(hour, minute).format(shortTime())
    fun month(ym: YearMonth): String = ym.month.getDisplayName(TextStyle.SHORT, Locale.getDefault())

    fun dueIn(deadline: Long, now: Long): String {
        val diff = deadline - now
        return when {
            diff <= 0 -> "Overdue"
            diff < HOUR_MS -> "Due in ${maxOf(1L, diff / 60_000)} min"
            diff < 48 * HOUR_MS -> "Due in ${diff / HOUR_MS} h"
            else -> "Due in ${diff / DAY_MS} days"
        }
    }

    fun percent(f: Float?): String = f?.let { "${(it * 100).roundToInt()}%" } ?: "—"

    fun prepDays(days: Int): String = when (days) {
        0 -> "Just submit"
        1 -> "1 day"
        else -> "$days days"
    }
}
