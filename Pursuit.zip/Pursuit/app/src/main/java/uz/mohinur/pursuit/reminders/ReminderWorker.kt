package uz.mohinur.pursuit.reminders

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import uz.mohinur.pursuit.PursuitApp
import uz.mohinur.pursuit.data.ReminderMode
import uz.mohinur.pursuit.domain.ReminderContent
import java.time.LocalDate
import java.time.ZoneId

class ReminderWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val app = applicationContext as PursuitApp
        val settings = app.settingsStore.settings.value
        if (settings.reminderMode == ReminderMode.OFF) return Result.success()

        val events = app.eventStore.load()
        val zone = ZoneId.systemDefault()
        val daily = settings.reminderMode == ReminderMode.DAILY
        val digest = daily || LocalDate.now(zone).dayOfWeek == settings.weeklyDay

        val message = ReminderContent.build(
            events = events,
            now = System.currentTimeMillis(),
            digest = digest,
            daily = daily,
            zone = zone,
        ) ?: return Result.success()

        Notifications.show(applicationContext, if (digest) DIGEST_ID else URGENT_ID, message)
        return Result.success()
    }

    private companion object {
        const val DIGEST_ID = 1001
        const val URGENT_ID = 1002
    }
}
