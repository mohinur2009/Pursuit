# Pursuit — plan every deadline, apply to more, track your wins

An Android app (Kotlin + Jetpack Compose) for students who juggle hackathons, pitch competitions, internships, olympiads, scholarships and quizzes.

## What it does

| Tab | What you see |
|---|---|
| **Plan** | Greeting, a 7-day strip with dots on deadline days, a big **Focus now** card for your #1 event, then your ranked **Up next** list. Each card shows the deadline, a "Start by" date, and a ring that fills up as the deadline gets closer. Events you can't fit in time are marked **At risk**. Passed deadlines go to a separate section with "I applied" / "Skip it". |
| **Results** | Everything you applied to. Tap **Accepted**, **Won** or **Rejected** when you hear back. |
| **Tracker** | Win rate (donut), "Great progress 🔥" card comparing this month with last month, totals (applied, accepted, won, waiting, missed, applied on time), a 6‑month activity chart, and a this‑month vs last‑month table. |
| **Settings** | Your name, reminders (Off / Daily / Weekly, day and time), how the ranking works, privacy policy, delete all data. |

Tap **+** to add an event: name, type, deadline date and time, importance (Low / Medium / High / Must do), days needed to prepare, optional link and notes.

## How the list is ordered

1. Anything due in the next 24 hours goes on top.
2. Every other event gets a **start-by date** = deadline − days you need to prepare.
3. Importance pulls an event earlier: Medium by 1 day, High by 2, Must do by 3.
   So a Must-do Pizza Pitch beats a Low quiz whose start date is up to 3 days earlier — but not one a week earlier.
4. The app "walks" the list in that order. If earlier events use up the time, later ones are marked **At risk** so you can decide what to drop.

Ordering by start date is close to "earliest deadline first", which is the order that lets you finish the most things on time — importance only bends it by a few days. The logic lives in `domain/Prioritizer.kt` and is covered by unit tests.

## Open and run it

1. Unzip, then in Android Studio choose **File → Open** and pick the `Pursuit` folder.
2. Let Gradle sync. If Studio offers to update library or plugin versions, accept.
3. Press **Run** on an emulator or your phone.
4. Run the tests: right-click `app/src/test` → **Run Tests**.

## Before you publish — change these

- [ ] `applicationId` in `app/build.gradle.kts` (it can never change after the first upload). The package/namespace can stay.
- [ ] `[your contact email]` in `PRIVACY_POLICY.md` **and** `ui/PrivacyPolicy.kt`.
- [ ] Host `PRIVACY_POLICY.md` somewhere public (GitHub Pages, Google Sites, Notion public page) and keep the URL.
- [ ] Bump `versionCode` (+1) for every upload.

## Google Play checklist

**Already handled in the code**
- Targets **Android 16 (API 36)** — required for new apps and updates since 31 Aug 2026.
- Only one permission: **notifications**, requested at the moment you turn reminders on (Android 13+).
- No internet permission, no ads, no analytics, no account → simplest possible Data safety form.
- Reminders use **WorkManager**, not exact alarms (Play restricts exact alarms to alarm/calendar apps) and no foreground service.
- Edge-to-edge layout and predictive back (Android 16 enforces both).
- In-app privacy policy and "Delete all my data".

**Build the upload file**
- Build → **Generate Signed App Bundle** → Android App Bundle (.aab) → create an upload key.
- Keep the `.jks` file and its passwords safe (not in the project folder, not on GitHub). Let Play manage the app signing key (Play App Signing).

**Play Console → App content answers**
| Section | Answer |
|---|---|
| Privacy policy | Your hosted URL |
| Ads | No ads |
| App access | All functionality is available without special access |
| Content rating | Fill the questionnaire; category **Utility / Productivity**; answer "No" to violence, sexual content, gambling, user interaction etc. |
| Target audience | **13–15, 16–17, 18+**. Don't include under‑13 unless you want the extra Families policy requirements. |
| Data safety | "Does your app collect or share any of the required user data types?" → **No** |
| Government / financial / health apps | No |

**Store listing**
- App icon 512×512 → `store-assets/play-icon-512.png`
- Feature graphic 1024×500 → `store-assets/feature-graphic-1024x500.png`
- At least 2 phone screenshots → take them from the emulator (add 4–5 sample events first).
- Short description (max 80 characters):
  `Plan hackathons, internships & deadlines in the best order. Track your wins.`
- Full description (draft):

  > Pursuit helps students say yes to more opportunities.
  >
  > Add every hackathon, pitch competition, internship, olympiad, scholarship or quiz with its deadline and how important it is. Pursuit puts them in the order that lets you apply to as many as possible: what's due soonest and needs the most preparation comes first, and important events can move ahead of less important ones a few days earlier.
  >
  > • Focus card: your one most important thing right now
  > • "Start by" dates based on how long you need to prepare
  > • "At risk" warnings when you can't fit everything
  > • Daily or weekly reminders and a heads-up 2 days before deadlines
  > • Record results: accepted, won or rejected
  > • Tracker: win rate, monthly progress and a 6-month chart
  >
  > No account. No ads. Your data never leaves your phone.

**Testing gate for new personal developer accounts**
If your Play developer account is a personal account created after 13 Nov 2023, you must run a **closed test with at least 12 testers who stay opted in for 14 days in a row** before you can apply for production access. Start this early — friends from your school IT club and Pioneer cohort are the easiest testers. Organisation accounts are exempt.

## Project map

```
app/src/main/java/uz/mohinur/pursuit/
├─ data/        Event model, JSON storage (EventStore), settings
├─ domain/      Prioritizer (ranking), StatsCalculator (tracker), ReminderContent
├─ reminders/   WorkManager worker, scheduler, notifications
└─ ui/          Theme, shared components, the 5 screens, ViewModel
app/src/test/   Unit tests for ranking and stats
```

## Ideas for version 1.1
- Uzbek and Russian translations (move UI text to `strings.xml`).
- Home-screen widget with the Focus card.
- Export / import your list as a file.
