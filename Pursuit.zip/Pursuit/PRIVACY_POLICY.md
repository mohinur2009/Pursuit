# Pursuit — Privacy Policy

_Last updated: 13 October 2026_

Pursuit is a planner that helps students keep track of hackathons, internships, competitions and other opportunities.

## What we collect
Nothing. Pursuit has no account, no ads, no analytics and no access to the internet. The events, results and settings you enter are stored only on your phone, inside the app's private storage.

## Notifications
If you turn on reminders, Pursuit shows notifications that are created on your phone from your own list. Nothing is sent to a server.

## Backups
If Android backup is turned on for your Google account, Android may include Pursuit's data in your personal device backup, which is handled by Google under your account settings. The developer cannot see it.

## Deleting your data
Use Settings → "Delete all my data", or uninstall the app. Both remove everything Pursuit has stored.

## Children
Pursuit is meant for students aged 13 and over and does not knowingly collect any information from anyone.

## Changes
If this policy changes, the new version will be published at this address and in the app.

## Contact
Questions: [your contact email]
